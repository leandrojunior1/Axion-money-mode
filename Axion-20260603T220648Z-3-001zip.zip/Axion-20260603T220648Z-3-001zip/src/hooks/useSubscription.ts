import { useState, useEffect, useCallback } from "react";

interface SubscriptionState {
  active: boolean;
  loading: boolean;
  status: string | null;
}

const cache: Record<string, { active: boolean; status: string | null; ts: number }> = {};
const CACHE_TTL = 60_000;

export function useSubscription(userId: string | null) {
  const [state, setState] = useState<SubscriptionState>({
    active: false,
    loading: !!userId,
    status: null,
  });

  const check = useCallback(async () => {
    if (!userId) {
      setState({ active: false, loading: false, status: null });
      return;
    }

    const cached = cache[userId];
    if (cached && Date.now() - cached.ts < CACHE_TTL) {
      setState({ active: cached.active, loading: false, status: cached.status });
      return;
    }

    setState((s) => ({ ...s, loading: true }));
    try {
      const res = await fetch(`/api/subscription/status?userId=${encodeURIComponent(userId)}`);
      const data = await res.json();
      cache[userId] = { active: data.active, status: data.status ?? null, ts: Date.now() };
      setState({ active: data.active, loading: false, status: data.status ?? null });
    } catch {
      setState({ active: false, loading: false, status: null });
    }
  }, [userId]);

  useEffect(() => {
    check();
  }, [check]);

  const invalidate = () => {
    if (userId) delete cache[userId];
    check();
  };

  return { ...state, refetch: invalidate };
}
