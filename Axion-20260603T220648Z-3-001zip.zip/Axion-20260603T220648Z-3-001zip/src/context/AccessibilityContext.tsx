import React, { createContext, useContext, useEffect, useState } from "react";

export type FontSize = "normal" | "large" | "xlarge";

interface AccessibilityState {
  fontSize: FontSize;
  highContrast: boolean;
  reducedMotion: boolean;
  dyslexiaFont: boolean;
  setFontSize: (size: FontSize) => void;
  setHighContrast: (v: boolean) => void;
  setReducedMotion: (v: boolean) => void;
  setDyslexiaFont: (v: boolean) => void;
}

const AccessibilityContext = createContext<AccessibilityState>({
  fontSize: "normal",
  highContrast: false,
  reducedMotion: false,
  dyslexiaFont: false,
  setFontSize: () => {},
  setHighContrast: () => {},
  setReducedMotion: () => {},
  setDyslexiaFont: () => {},
});

const STORAGE_KEY = "axion_accessibility";

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const saved = load();

  const [fontSize, setFontSizeState] = useState<FontSize>(saved.fontSize ?? "normal");
  const [highContrast, setHighContrastState] = useState<boolean>(saved.highContrast ?? false);
  const [reducedMotion, setReducedMotionState] = useState<boolean>(saved.reducedMotion ?? false);
  const [dyslexiaFont, setDyslexiaFontState] = useState<boolean>(saved.dyslexiaFont ?? false);

  function persist(patch: object) {
    const prev = load();
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...prev, ...patch }));
  }

  const setFontSize = (size: FontSize) => {
    setFontSizeState(size);
    persist({ fontSize: size });
  };
  const setHighContrast = (v: boolean) => {
    setHighContrastState(v);
    persist({ highContrast: v });
  };
  const setReducedMotion = (v: boolean) => {
    setReducedMotionState(v);
    persist({ reducedMotion: v });
  };
  const setDyslexiaFont = (v: boolean) => {
    setDyslexiaFontState(v);
    persist({ dyslexiaFont: v });
  };

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("font-large", "font-xlarge");
    if (fontSize === "large") root.classList.add("font-large");
    if (fontSize === "xlarge") root.classList.add("font-xlarge");
  }, [fontSize]);

  useEffect(() => {
    document.documentElement.classList.toggle("high-contrast", highContrast);
  }, [highContrast]);

  useEffect(() => {
    document.documentElement.classList.toggle("reduce-motion", reducedMotion);
  }, [reducedMotion]);

  useEffect(() => {
    document.documentElement.classList.toggle("dyslexia-font", dyslexiaFont);
  }, [dyslexiaFont]);

  return (
    <AccessibilityContext.Provider
      value={{ fontSize, highContrast, reducedMotion, dyslexiaFont, setFontSize, setHighContrast, setReducedMotion, setDyslexiaFont }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  return useContext(AccessibilityContext);
}
