import { db, isRealFirebase, handleFirestoreError, OperationType } from "../firebase";
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
} from "firebase/firestore";
import { UserProfile, RiskReport, ChatMessage } from "../types";

// Key handles for local storage lists
const LOCAL_PROFILE_KEY_PREFIX = "axion_profile_";
const LOCAL_REPORTS_KEY = "axion_reports";
const LOCAL_CHATS_KEY = "axion_chats";

function getLocalReports(): RiskReport[] {
  const data = localStorage.getItem(LOCAL_REPORTS_KEY);
  return data ? JSON.parse(data) : [];
}

function setLocalReports(reports: RiskReport[]) {
  localStorage.setItem(LOCAL_REPORTS_KEY, JSON.stringify(reports));
}

function getLocalChats(): ChatMessage[] {
  const data = localStorage.getItem(LOCAL_CHATS_KEY);
  return data ? JSON.parse(data) : [];
}

function setLocalChats(chats: ChatMessage[]) {
  localStorage.setItem(LOCAL_CHATS_KEY, JSON.stringify(chats));
}

// 1. Get User Profile
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  if (isRealFirebase && db) {
    const docPath = `users/${userId}`;
    try {
      const snap = await getDoc(doc(db, "users", userId));
      if (snap.exists()) {
        return snap.data() as UserProfile;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, docPath);
      return null;
    }
  } else {
    const data = localStorage.getItem(LOCAL_PROFILE_KEY_PREFIX + userId);
    return data ? JSON.parse(data) : null;
  }
}

// 2. Save User Profile
export async function saveUserProfile(profile: UserProfile): Promise<void> {
  if (isRealFirebase && db) {
    const docPath = `users/${profile.userId}`;
    try {
      await setDoc(doc(db, "users", profile.userId), profile);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, docPath);
    }
  } else {
    localStorage.setItem(LOCAL_PROFILE_KEY_PREFIX + profile.userId, JSON.stringify(profile));
  }
}

// 3. Update User Profile Risk Profile
export async function updateUserRiskProfile(
  userId: string,
  riskProfile: "conservative" | "moderate" | "aggressive"
): Promise<void> {
  if (isRealFirebase && db) {
    const docPath = `users/${userId}`;
    try {
      await updateDoc(doc(db, "users", userId), { riskProfile });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, docPath);
    }
  } else {
    const profile = await getUserProfile(userId);
    if (profile) {
      profile.riskProfile = riskProfile;
      localStorage.setItem(LOCAL_PROFILE_KEY_PREFIX + userId, JSON.stringify(profile));
    }
  }
}

// 4. Save Risk Report
export async function saveRiskReport(userId: string, company: string, riskScore: number, analysis: string, recommendations: string): Promise<RiskReport> {
  const newReport: RiskReport = {
    reportId: "rep_" + Math.random().toString(36).substr(2, 9),
    userId,
    company,
    riskScore,
    analysis,
    recommendations,
    createdAt: new Date().toISOString(),
  };

  if (isRealFirebase && db) {
    const docPath = `reports/${newReport.reportId}`;
    try {
      await setDoc(doc(db, "reports", newReport.reportId), newReport);
      return newReport;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, docPath);
      return newReport;
    }
  } else {
    const reports = getLocalReports();
    reports.push(newReport);
    setLocalReports(reports);
    return newReport;
  }
}

// 5. Get User Risk Reports
export async function getUserRiskReports(userId: string): Promise<RiskReport[]> {
  if (isRealFirebase && db) {
    const collName = "reports";
    try {
      const q = query(
        collection(db, collName),
        where("userId", "==", userId),
        orderBy("createdAt", "desc")
      );
      const snap = await getDocs(q);
      const list: RiskReport[] = [];
      snap.forEach((d) => {
        list.push(d.data() as RiskReport);
      });
      return list;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, collName);
      return [];
    }
  } else {
    return getLocalReports()
      .filter((r) => r.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}

// 6. Save Chat Message interaction
export async function saveChatMessage(userId: string, message: string, response: string): Promise<ChatMessage> {
  const newChat: ChatMessage = {
    chatId: "chat_" + Math.random().toString(36).substr(2, 9),
    userId,
    message,
    response,
    createdAt: new Date().toISOString(),
  };

  if (isRealFirebase && db) {
    const docPath = `chats/${newChat.chatId}`;
    try {
      await setDoc(doc(db, "chats", newChat.chatId), newChat);
      return newChat;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, docPath);
      return newChat;
    }
  } else {
    const chats = getLocalChats();
    chats.push(newChat);
    setLocalChats(chats);
    return newChat;
  }
}

// 7. Get User Chats
export async function getUserChats(userId: string): Promise<ChatMessage[]> {
  if (isRealFirebase && db) {
    const collName = "chats";
    try {
      const q = query(
        collection(db, collName),
        where("userId", "==", userId),
        orderBy("createdAt", "desc")
      );
      const snap = await getDocs(q);
      const list: ChatMessage[] = [];
      snap.forEach((d) => {
        list.push(d.data() as ChatMessage);
      });
      return list;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, collName);
      return [];
    }
  } else {
    return getLocalChats()
      .filter((c) => c.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}
