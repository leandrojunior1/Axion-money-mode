import { auth, isRealFirebase } from "../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
} from "firebase/auth";
import { UserProfile } from "../types";

export interface DBUser {
  userId: string;
  email: string;
  displayName: string;
  createdAt: string;
  password?: string;
  riskProfile?: "conservative" | "moderate" | "aggressive";
}

// Memory / LocalStorage based state when Firebase is placeholder
const LOCAL_USERS_KEY = "axion_local_users";
const ACTIVE_USER_KEY = "axion_active_user";

function getLocalUsers(): DBUser[] {
  const data = localStorage.getItem(LOCAL_USERS_KEY);
  return data ? JSON.parse(data) : [];
}

function setLocalUsers(users: DBUser[]) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

function getActiveLocalUser(): DBUser | null {
  const data = localStorage.getItem(ACTIVE_USER_KEY);
  return data ? JSON.parse(data) : null;
}

function setActiveLocalUser(user: DBUser | null) {
  if (user) {
    localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(ACTIVE_USER_KEY);
  }
}

type AuthCallback = (user: UserProfile | null) => void;
const listeners: AuthCallback[] = [];

// Triggers listeners when auth state changes in mock mode
function notifyListeners(user: UserProfile | null) {
  listeners.forEach((cb) => cb(user));
}

// Standard onAuthStateChange interface
export function subscribeToAuth(callback: AuthCallback) {
  listeners.push(callback);
  
  if (isRealFirebase && auth) {
    return onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        callback({
          userId: firebaseUser.uid,
          email: firebaseUser.email || "",
          displayName: firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "Usuário",
          createdAt: new Date().toISOString(),
        });
      } else {
        callback(null);
      }
    });
  } else {
    // Local / Mock mode
    const cur = getActiveLocalUser();
    if (cur) {
      callback({
        userId: cur.userId,
        email: cur.email,
        displayName: cur.displayName,
        createdAt: cur.createdAt,
        riskProfile: cur.riskProfile,
      });
    } else {
      callback(null);
    }
    
    return () => {
      const idx = listeners.indexOf(callback);
      if (idx !== -1) listeners.splice(idx, 1);
    };
  }
}

// Register
export async function registerWithEmail(email: string, pass: string, name: string): Promise<UserProfile> {
  if (isRealFirebase && auth) {
    const creds = await createUserWithEmailAndPassword(auth, email, pass);
    if (creds.user) {
      await updateProfile(creds.user, { displayName: name });
      const profile: UserProfile = {
        userId: creds.user.uid,
        email: creds.user.email || email,
        displayName: name,
        createdAt: new Date().toISOString(),
      };
      return profile;
    }
    throw new Error("Não foi possível criar o usuário no Firebase.");
  } else {
    // Local registration
    const users = getLocalUsers();
    if (users.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
      throw new Error("E-mail já cadastrado.");
    }
    const newUser: DBUser = {
      userId: "local_" + Math.random().toString(36).substr(2, 9),
      email: email,
      displayName: name,
      createdAt: new Date().toISOString(),
      password: pass,
      riskProfile: "moderate",
    };
    users.push(newUser);
    setLocalUsers(users);
    setActiveLocalUser(newUser);
    
    const profile: UserProfile = {
      userId: newUser.userId,
      email: newUser.email,
      displayName: newUser.displayName,
      createdAt: newUser.createdAt,
      riskProfile: newUser.riskProfile,
    };
    notifyListeners(profile);
    return profile;
  }
}

// Log In
export async function loginWithEmail(email: string, pass: string): Promise<UserProfile> {
  if (isRealFirebase && auth) {
    const creds = await signInWithEmailAndPassword(auth, email, pass);
    const profile: UserProfile = {
      userId: creds.user.uid,
      email: creds.user.email || email,
      displayName: creds.user.displayName || creds.user.email?.split("@")[0] || "Usuário",
      createdAt: new Date().toISOString(),
    };
    return profile;
  } else {
    // Local verification
    const users = getLocalUsers();
    const found = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === pass
    );
    if (!found) {
      throw new Error("E-mail ou senha inválidos.");
    }
    setActiveLocalUser(found);
    const profile: UserProfile = {
      userId: found.userId,
      email: found.email,
      displayName: found.displayName,
      createdAt: found.createdAt,
      riskProfile: found.riskProfile,
    };
    notifyListeners(profile);
    return profile;
  }
}

// Sign Out
export async function logoutUser() {
  if (isRealFirebase && auth) {
    await signOut(auth);
  } else {
    setActiveLocalUser(null);
    notifyListeners(null);
  }
}
