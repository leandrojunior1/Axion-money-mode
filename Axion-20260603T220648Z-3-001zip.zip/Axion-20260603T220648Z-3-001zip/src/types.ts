export interface UserProfile {
    userId: string;
    email: string;
    displayName: string;
    createdAt: string;
    riskProfile?: "conservative" | "moderate" | "aggressive";
  }
  
  export interface RiskReport {
    reportId: string;
    userId: string;
    company: string;
    riskScore: number;
    analysis: string;
    recommendations: string;
    createdAt: string;
  }
  
  export interface ChatMessage {
    chatId: string;
    userId: string;
    message: string;
    response: string;
    createdAt: string;
  }
  
  export interface FinancialNews {
    id: string;
    title: string;
    source: string;
    time: string;
    category: "Mercado" | "Empresas" | "Tecnologia" | "Moedas";
    impact: "Alta" | "Média" | "Baixa";
    summary: string;
  }
  
  export interface ServiceDetail {
    id: string;
    title: string;
    description: string;
    icon: string;
    details: string[];
  }
  