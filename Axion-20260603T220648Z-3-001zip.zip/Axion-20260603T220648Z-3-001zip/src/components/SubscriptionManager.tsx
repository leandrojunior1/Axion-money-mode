import React, { useState } from "react";
import { X, Zap, CheckCircle, Crown, AlertCircle, Loader2, ExternalLink, CreditCard, XCircle } from "lucide-react";
import { UserProfile } from "../types";

interface SubscriptionManagerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  isSubscribed: boolean;
  onOpenSubscription: () => void;
}

export default function SubscriptionManager({
  isOpen,
  onClose,
  currentUser,
  isSubscribed,
  onOpenSubscription,
}: SubscriptionManagerProps) {
  const [loadingPortal, setLoadingPortal] = useState(false);
  const [portalError, setPortalError] = useState("");

  const handleOpenPortal = async () => {
    setLoadingPortal(true);
    setPortalError("");
    try {
      const res = await fetch("/api/subscription/portal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUser.userId }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setPortalError("Não foi possível abrir o portal. Tente novamente.");
      }
    } catch {
      setPortalError("Erro de conexão. Tente novamente.");
    } finally {
      setLoadingPortal(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="w-full max-w-md bg-[#0F1115] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">

        {/* Header */}
        <div className="relative bg-gradient-to-r from-slate-900 via-slate-800/50 to-slate-900 border-b border-slate-800 px-6 pt-6 pb-5">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[1px] w-48 bg-gradient-to-r from-blue-500/0 via-blue-400/60 to-blue-500/0" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X size={18} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
              <Crown size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Minha Conta</p>
              <h2 className="text-lg font-extrabold text-white">Gerenciar Assinatura</h2>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="px-6 pt-5 pb-4 border-b border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-extrabold text-sm font-mono">
              {currentUser.displayName.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="text-sm font-bold text-white">{currentUser.displayName}</p>
              <p className="text-xs text-slate-400">{currentUser.email}</p>
            </div>
          </div>
        </div>

        {/* Subscription Status */}
        <div className="px-6 py-5 space-y-4">

          {/* Status Card */}
          <div className={`rounded-2xl border p-4 flex items-center gap-4 ${
            isSubscribed
              ? "bg-emerald-500/5 border-emerald-500/20"
              : "bg-slate-900 border-slate-800"
          }`}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isSubscribed ? "bg-emerald-500/10" : "bg-slate-800"
            }`}>
              {isSubscribed
                ? <CheckCircle size={20} className="text-emerald-400" />
                : <XCircle size={20} className="text-slate-500" />
              }
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">
                Status do Plano
              </p>
              {isSubscribed ? (
                <>
                  <p className="text-sm font-extrabold text-emerald-400">Axion PRO — Ativo</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Acesso completo: notícias, assistente e análises ilimitadas
                  </p>
                </>
              ) : (
                <>
                  <p className="text-sm font-extrabold text-white">Plano Gratuito</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Análise de risco disponível. Notícias e assistente bloqueados.
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          {isSubscribed ? (
            <div className="space-y-3">
              <button
                onClick={handleOpenPortal}
                disabled={loadingPortal}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sm font-bold text-white transition disabled:opacity-60"
              >
                {loadingPortal
                  ? <><Loader2 size={16} className="animate-spin" /> Abrindo portal...</>
                  : <><CreditCard size={16} /> Gerenciar Faturamento e Cancelar<ExternalLink size={12} className="text-slate-500" /></>
                }
              </button>

              {portalError && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-400">
                  <AlertCircle size={14} />
                  {portalError}
                </div>
              )}

              <p className="text-[11px] text-slate-600 text-center leading-relaxed">
                O portal do Stripe permite visualizar faturas, atualizar o método de pagamento e cancelar a assinatura a qualquer momento.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <button
                onClick={() => { onClose(); onOpenSubscription(); }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-sm font-bold text-white transition shadow-lg shadow-blue-500/15"
              >
                <Zap size={16} />
                Assinar Axion PRO
              </button>
              <p className="text-[11px] text-slate-600 text-center">
                Cancele quando quiser. Sem fidelidade.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
