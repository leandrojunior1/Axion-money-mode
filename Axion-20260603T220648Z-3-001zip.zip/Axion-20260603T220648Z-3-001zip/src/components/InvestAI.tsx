import React, { useState, useEffect } from "react";
import { UserProfile, RiskReport, ChatMessage, FinancialNews } from "../types";
import {
  saveRiskReport,
  getUserRiskReports,
  saveChatMessage,
  getUserChats,
} from "../services/db";
import {
  TrendingUp,
  Cpu,
  BarChart,
  Grid,
  Bot,
  Send,
  Loader2,
  FileText,
  AlertTriangle,
  Award,
  Lock,
  ArrowRight,
  RefreshCw,
  Clock,
  History,
  TrendingDown,
  Info,
  DollarSign,
  Globe,
  Activity,
  Flame,
  ChevronUp,
  ChevronDown,
  Zap,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import investChartImage from "../assets/images/invest_ai_chart_1780093086631.png";

interface InvestAIProps {
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  isSubscribed?: boolean;
  subscriptionLoading?: boolean;
  onOpenSubscription?: () => void;
}

const PRESET_NEWS: FinancialNews[] = [
  {
    id: "n1",
    title:
      "Ibovespa avança com alta de commodities e otimismo corporativo na América Latina",
    source: "Axion Market Reports",
    time: "Há 5 min",
    category: "Mercado",
    impact: "Alta",
    summary:
      "As principais ações de exportação apresentaram forte alta nas primeiras horas de negociação, impulsionadas pelo preço do minério de ferro e petróleo bruto. Analistas apontam para fluxos de capital estrangeiro.",
  },
  {
    id: "n2",
    title:
      "Fed sinaliza estabilidade na taxa de juros norte-americana frente à controle inflacionário",
    source: "Axion News",
    time: "Há 18 min",
    category: "Moedas",
    impact: "Alta",
    summary:
      "O comitê econômico do banco central americano indicou uma postura mais leve visando decolar empregos, reduzindo especulações de novos apertos fiscais para o próximo mês.",
  },
  {
    id: "n3",
    title:
      "Setor de tecnologia impulsiona Nasdaq com nova corrida por chips analíticos inteligentes",
    source: "Axion Tech Labs",
    time: "Há 41 min",
    category: "Tecnologia",
    impact: "Média",
    summary:
      "Faturamento surpreendente em fabricantes de silício local acendeu novas perspectivas positivas para investidores. Desenvolvedores de softwares como a Axion mantêm o radar em inovações de baixo carbono.",
  },
  {
    id: "n4",
    title:
      "Relatórios trimestrais mostram recuperação robusta no setor de varejo pós-correção cambial",
    source: "Mercado Aliança",
    time: "Há 1h",
    category: "Empresas",
    impact: "Baixa",
    summary:
      "Grandes cadeias de lojas aumentaram as margens operacionais em 3.2%, auxiliadas por campanhas customizadas e digitalização de pagamentos, superando expectativas moderadas.",
  },
  {
    id: "n5",
    title:
      "Petróleo atinge estabilidade global após negociações diplomáticas multilaterais",
    source: "Energia Total",
    time: "Há 2h",
    category: "Mercado",
    impact: "Média",
    summary:
      "Preços futuros dos contratos Brent flutuam na faixa esperada de US$ 78-81 por barril. Especialistas antecipam riscos moderados nos relatórios do próximo trimestre.",
  },
];

const CHAT_SUGGESTIONS = [
  "Quais as tendências para o setor de Tecnologia neste trimestre?",
  "Como definir a mitigação num portfólio de risco Moderado?",
  "O que significa risco sistêmico entre empresas exportadoras?",
  "Qual o impacto cambial atual no setor de commodities?",
];

const MARKET_INDICES = [
  {
    name: "Ibovespa",
    value: "127.842",
    change: "+1.43%",
    up: true,
    region: "BR",
  },
  {
    name: "S&P 500",
    value: "5.308,15",
    change: "+0.87%",
    up: true,
    region: "US",
  },
  {
    name: "Nasdaq",
    value: "18.671,29",
    change: "+1.12%",
    up: true,
    region: "US",
  },
  {
    name: "Dow Jones",
    value: "39.169,52",
    change: "-0.21%",
    up: false,
    region: "US",
  },
  {
    name: "FTSE 100",
    value: "8.415,30",
    change: "+0.55%",
    up: true,
    region: "UK",
  },
  { name: "DAX", value: "18.892,14", change: "+0.34%", up: true, region: "DE" },
];

const MARKET_CURRENCIES = [
  { pair: "USD/BRL", value: "5,1248", change: "+0.28%", up: false },
  { pair: "EUR/BRL", value: "5,5690", change: "-0.14%", up: true },
  { pair: "BTC/USD", value: "67.842", change: "+2.34%", up: true },
  { pair: "ETH/USD", value: "3.512", change: "+1.87%", up: true },
];

const MARKET_COMMODITIES = [
  {
    name: "Petróleo Brent",
    value: "US$ 82,40",
    change: "+0.91%",
    up: true,
    unit: "/barril",
  },
  { name: "Ouro", value: "US$ 2.318", change: "+0.45%", up: true, unit: "/oz" },
  {
    name: "Minério de Ferro",
    value: "US$ 119,30",
    change: "-1.20%",
    up: false,
    unit: "/ton",
  },
  {
    name: "Milho",
    value: "US$ 460,75",
    change: "-0.63%",
    up: false,
    unit: "/bu",
  },
];

const PORTFOLIO_ALLOCATION = [
  { label: "Renda Variável BR", pct: 35, color: "bg-blue-500" },
  { label: "Renda Variável EUA", pct: 25, color: "bg-cyan-400" },
  { label: "Renda Fixa", pct: 20, color: "bg-emerald-400" },
  { label: "Criptoativos", pct: 10, color: "bg-violet-400" },
  { label: "Commodities", pct: 7, color: "bg-amber-400" },
  { label: "Caixa", pct: 3, color: "bg-slate-400" },
];

function PaywallBanner({
  onOpenSubscription,
}: {
  onOpenSubscription?: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative rounded-3xl overflow-hidden border border-slate-800 bg-[#161B22] p-8 lg:p-12 text-center space-y-6 shadow-2xl"
    >
      <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[2px] w-64 bg-gradient-to-r from-blue-500/0 via-blue-400/80 to-blue-500/0" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-slate-950 border border-slate-800 mx-auto">
        <Lock className="text-blue-400" size={24} />
      </div>

      <div className="space-y-2 max-w-md mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 mb-2">
          <Zap size={12} className="text-blue-400" />
          <span className="text-[11px] font-bold text-blue-400 uppercase tracking-widest">
            Axion PRO
          </span>
        </div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight">
          Recurso Exclusivo para Assinantes
        </h2>
        <p className="text-sm text-slate-400 leading-relaxed">
          Este módulo está disponível apenas no plano{" "}
          <strong className="text-white">Axion PRO</strong>. Assine agora para
          acessar notícias em tempo real, o chatbot assistente e análises
          ilimitadas.
        </p>
      </div>

      <button
        onClick={onOpenSubscription}
        className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 rounded-xl transition transform hover:-translate-y-0.5 shadow-lg"
      >
        <Zap size={16} />
        Assinar Axion PRO
        <ArrowRight size={14} />
      </button>
    </motion.div>
  );
}

export default function InvestAI({
  currentUser,
  onOpenAuth,
  isSubscribed = false,
  subscriptionLoading = false,
  onOpenSubscription,
}: InvestAIProps) {
  // Navigation / Tabs inside logged-in InvestAI
  const [activeTab, setActiveTab] = useState<
    "assistant" | "analyzer" | "news" | "indicadores"
  >("analyzer");

  // State for AI Assistant Chat
  const [chatInput, setChatInput] = useState("");
  const [chats, setChats] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // State for Automated Risk Report Generator
  const [companyInput, setCompanyInput] = useState("");
  const [reports, setReports] = useState<RiskReport[]>([]);
  const [activeReport, setActiveReport] = useState<RiskReport | null>(null);
  const [isReportLoading, setIsReportLoading] = useState(false);
  const [errorText, setErrorText] = useState("");

  // Loading reports and chats once currentUser is logged in
  useEffect(() => {
    if (currentUser) {
      loadHistory();
    }
  }, [currentUser]);

  const loadHistory = async () => {
    if (!currentUser) return;
    try {
      const savedChats = await getUserChats(currentUser.userId);
      const savedReports = await getUserRiskReports(currentUser.userId);
      setChats(savedChats);
      setReports(savedReports);
      if (savedReports.length > 0) {
        setActiveReport(savedReports[0]);
      }
    } catch (e) {
      console.error("Erro ao carregar histórico: ", e);
    }
  };

  // 1. Submit Chat
  const handleSendChat = async (msgText?: string) => {
    const textToSend = msgText || chatInput;
    if (!textToSend.trim() || !currentUser) return;

    const userMessage = textToSend;
    setChatInput("");
    setIsChatLoading(true);

    const tempChat: ChatMessage = {
      chatId: "temp_" + Math.random().toString(),
      userId: currentUser.userId,
      message: userMessage,
      response: "Interpretando dados do mercado financeiro...",
      createdAt: new Date().toISOString(),
    };
    setChats((prev) => [tempChat, ...prev]);

    try {
      const res = await fetch("/api/invest-ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      });

      if (!res.ok) {
        throw new Error("Não foi possível carregar resposta da Invest-AI.");
      }

      const data = await res.json();

      // Save actually to DB
      const finalChat = await saveChatMessage(
        currentUser.userId,
        userMessage,
        data.response,
      );
      setChats((prev) =>
        prev.map((c) => (c.chatId === tempChat.chatId ? finalChat : c)),
      );
    } catch (err: any) {
      setChats((prev) =>
        prev.map((c) =>
          c.chatId === tempChat.chatId
            ? {
                ...c,
                response:
                  "Desculpe, ocorreu um erro de conexão com nossos servidores da Axion. Tente reiniciar a pergunta.",
              }
            : c,
        ),
      );
    } finally {
      setIsChatLoading(false);
    }
  };

  // 2. Submit Report Generation
  const handleGenerateReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyInput.trim() || !currentUser) return;

    setErrorText("");
    setIsReportLoading(true);
    const company = companyInput.toUpperCase();
    setCompanyInput("");

    try {
      const res = await fetch("/api/invest-ai/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          company,
          riskProfile: currentUser.riskProfile || "moderate",
        }),
      });

      if (!res.ok) {
        throw new Error(
          "Erro de infraestrutura ao solicitar o processamento do relatório.",
        );
      }

      const data = await res.json();

      // Save Report to DB
      const savedReport = await saveRiskReport(
        currentUser.userId,
        company,
        data.riskScore,
        data.analysis,
        data.recommendations,
      );

      setReports((prev) => [savedReport, ...prev]);
      setActiveReport(savedReport);
    } catch (err: any) {
      setErrorText(
        "Erro ao compilar o relatório inteligente. Por favor, tente novamente de forma objetiva.",
      );
    } finally {
      setIsReportLoading(false);
    }
  };

  const getRiskColor = (score: number) => {
    if (score < 30)
      return {
        text: "text-blue-400",
        bg: "bg-blue-500/10",
        border: "border-blue-500/20",
        progress: "bg-blue-400",
      };
    if (score < 65)
      return {
        text: "text-amber-400",
        bg: "bg-amber-500/10",
        border: "border-amber-500/20",
        progress: "bg-amber-400",
      };
    return {
      text: "text-rose-400",
      bg: "bg-rose-500/10",
      border: "border-rose-500/20",
      progress: "bg-rose-400",
    };
  };

  return (
    <div className="bg-[#0F1115] text-slate-300 min-h-screen py-8 lg:py-12 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded bg-blue-500/20 text-blue-400 text-xs font-bold font-mono">
                FLAGSHIP
              </span>
              <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center gap-2">
                <Bot className="text-blue-400" size={32} />
                Invest-AI
              </h1>
            </div>
            <p className="text-sm text-slate-400 max-w-xl leading-relaxed">
              Ambiente analítico com inteligência de ponta Axion. Monitore
              faturamentos, trace risco acionário sob medida e interprete
              tendências de empresas.
            </p>
          </div>

          {currentUser && (
            <div className="flex items-center gap-1.5 p-3 rounded-xl bg-[#161B22] border border-slate-800">
              <Clock size={16} className="text-slate-500" />
              <span className="text-xs text-slate-400 font-medium font-mono">
                Análise de Risco Ativa para perfil:
                <strong className="text-white text-xs ml-1.5 uppercase tracking-wide">
                  {currentUser.riskProfile === "conservative"
                    ? "Conservador"
                    : currentUser.riskProfile === "moderate"
                      ? "Moderado"
                      : "Arrojado"}
                </strong>
              </span>
            </div>
          )}
        </div>

        {/* If Not Logged In - High-End Prompt Banner */}
        {!currentUser ? (
          <div className="relative border border-slate-800 rounded-3xl overflow-hidden bg-[#161B22] shadow-2xl p-8 lg:p-12 text-center max-w-4xl mx-auto space-y-8 my-12">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

            {/* Glowing Accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[2px] w-64 bg-gradient-to-r from-blue-500/0 via-blue-400/80 to-blue-500/0" />

            <div className="max-w-2xl mx-auto space-y-4">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-slate-950 border border-slate-800 mb-2">
                <Lock className="text-blue-400" size={24} />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-none font-sans">
                Suite Financeira Exclusiva Invest-AI
              </h2>
              <p className="text-sm sm:text-base text-slate-400 leading-relaxed font-sans">
                Por motivos de segurança e conformidade de integridade de dados
                privados, o acesso aos relatórios automatizados, chat
                interpretativo sênior e leitura de ativos em tempo real requer{" "}
                <strong className="text-white">autenticação cadastrada</strong>.
              </p>
            </div>

            {/* Image Preview inside login wall */}
            <div className="max-w-md mx-auto rounded-2xl border border-slate-800 overflow-hidden shadow-xl p-1 bg-slate-950">
              <img
                src={investChartImage}
                alt="Invest-AI Analytics Preview"
                referrerPolicy="no-referrer"
                className="w-full rounded-xl grayscale opacity-40 shrink-0"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={onOpenAuth}
                className="px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 rounded-xl cursor-pointer transform hover:-translate-y-0.5 transition shadow-lg inline-flex items-center gap-1.5"
                id="investai-lockout-register-btn"
              >
                Cadastrar-se Gratuitamente na Axion
                <ArrowRight size={14} />
              </button>
              <button
                onClick={onOpenAuth}
                className="px-6 py-3 text-sm font-semibold text-white bg-slate-950 border border-slate-800 hover:bg-slate-850 rounded-xl cursor-pointer transition"
                id="investai-lockout-login-btn"
              >
                Já sou cadastrado / Autenticar
              </button>
            </div>
          </div>
        ) : (
          /* Logical Workspace: Logged In */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
            {/* Sidebar Navigation & Mini-Tools Panel */}
            <div className="lg:col-span-3 space-y-4">
              <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-4 space-y-2 shadow-xl">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest px-2 mb-3">
                  Painel de Operações
                </p>

                <button
                  onClick={() => setActiveTab("analyzer")}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left text-sm font-semibold transition ${
                    activeTab === "analyzer"
                      ? "bg-[#0F1115] text-blue-400 border border-slate-800/80 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                  }`}
                  id="tab-analyzer-btn"
                >
                  <span className="flex items-center gap-2.5">
                    <FileText size={18} />
                    Análise & Relatório de Risco
                  </span>
                  {reports.length > 0 && (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-[#0F1115] text-slate-400 rounded border border-slate-800 font-mono">
                      {reports.length}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab("assistant")}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left text-sm font-semibold transition ${
                    activeTab === "assistant"
                      ? "bg-[#0F1115] text-blue-400 border border-slate-800/80 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                  }`}
                  id="tab-assistant-btn"
                >
                  <span className="flex items-center gap-2.5">
                    <Bot size={18} />
                    Assistente Virtual Sênior
                  </span>
                  {!isSubscribed ? (
                    <Lock size={12} className="text-slate-600 shrink-0" />
                  ) : chats.length > 0 ? (
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-[#0F1115] text-slate-400 rounded border border-slate-800 font-mono">
                      {chats.length}
                    </span>
                  ) : null}
                </button>

                <button
                  onClick={() => setActiveTab("news")}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left text-sm font-semibold transition ${
                    activeTab === "news"
                      ? "bg-[#0F1115] text-blue-400 border border-slate-800/80 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                  }`}
                  id="tab-news-btn"
                >
                  <span className="flex items-center gap-2.5">
                    <TrendingUp size={18} />
                    Fluxo de Notícias Tempo Real
                  </span>
                  {!isSubscribed && (
                    <Lock size={12} className="text-slate-600 shrink-0" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab("indicadores")}
                  className={`w-full flex items-center gap-2.5 p-3 rounded-xl text-left text-sm font-semibold transition ${
                    activeTab === "indicadores"
                      ? "bg-[#0F1115] text-blue-400 border border-slate-800/80 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                  }`}
                  id="tab-indicadores-btn"
                >
                  <Globe size={18} />
                  Indicadores & Mercado
                </button>
              </div>

              {/* Sidebar: Historical generated reports */}
              {activeTab === "analyzer" && reports.length > 0 && (
                <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-4 space-y-3 shadow-xl">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1 flex items-center gap-1.5">
                    <History size={14} />
                    Histórico de Análises
                  </h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {reports.map((rep) => {
                      const colors = getRiskColor(rep.riskScore);
                      return (
                        <button
                          key={rep.reportId}
                          onClick={() => setActiveReport(rep)}
                          className={`w-full p-2.5 rounded-xl text-left transition border text-xs space-y-1 block ${
                            activeReport?.reportId === rep.reportId
                              ? "bg-[#0F1115] border-slate-800"
                              : "bg-transparent border-transparent hover:border-slate-850"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white text-xs">
                              {rep.company}
                            </span>
                            <span
                              className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${colors.bg} ${colors.text}`}
                            >
                              Risco {rep.riskScore}%
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500 font-mono">
                            {new Date(rep.createdAt).toLocaleDateString(
                              "pt-BR",
                            )}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Core Work Area */}
            <div className="lg:col-span-9">
              <AnimatePresence mode="wait">
                {/* 1. ANALYZER INTERFACE */}
                {activeTab === "analyzer" && (
                  <motion.div
                    key="analyzer-view"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    {/* Input card */}
                    <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-6 relative overflow-hidden shadow-xl">
                      <div className="space-y-2 mb-6">
                        <h2 className="text-lg font-bold text-white flex items-center gap-2">
                          <FileText size={20} className="text-blue-400" />
                          Gerar Relatório de Risco e Leitura de Tendências
                        </h2>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          Insira o ticker (ex:{" "}
                          <strong className="text-white">PETR4</strong>,{" "}
                          <strong className="text-white">VALE3</strong>) ou o
                          nome de qualquer empresa global. O Invest-AI lerá
                          tendências macroeconômicas e financeiros para calcular
                          um placar algorítmico de risco para você.
                        </p>
                      </div>

                      <form
                        onSubmit={handleGenerateReport}
                        className="flex flex-col sm:flex-row gap-3"
                      >
                        <input
                          type="text"
                          required
                          value={companyInput}
                          onChange={(e) => setCompanyInput(e.target.value)}
                          placeholder="Ex: AAPL, PETR4, NVDA, Magazine Luiza..."
                          disabled={isReportLoading}
                          className="flex-1 bg-[#0F1115] border border-slate-800 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none placeholder-slate-600 disabled:opacity-50"
                        />
                        <button
                          type="submit"
                          disabled={isReportLoading}
                          id="submit-generate-report-btn"
                          className="px-6 py-3 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 border border-blue-500/20 rounded-xl cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 shrink-0 transition"
                        >
                          {isReportLoading ? (
                            <>
                              <Loader2
                                size={16}
                                className="animate-spin text-white"
                              />
                              Analisando Ativos...
                            </>
                          ) : (
                            "Gerar Análise Crítica"
                          )}
                        </button>
                      </form>

                      {errorText && (
                        <p className="text-xs text-rose-400 mt-3 font-medium flex items-center gap-1">
                          <AlertTriangle size={14} />
                          {errorText}
                        </p>
                      )}
                    </div>

                    {/* Active report displays */}
                    {isReportLoading ? (
                      <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center space-y-4 shadow-xl">
                        <Loader2
                          size={40}
                          className="text-blue-400 animate-spin"
                        />
                        <div className="space-y-1">
                          <h3 className="text-sm font-bold text-white">
                            Interpretando Tendências de Companhias...
                          </h3>
                          <p className="text-xs text-slate-500 max-w-sm">
                            A inteligência financeira da Axion está consultando
                            balanços consolidados, integrando histórico
                            mercadológico e gerando relatórios de risco
                            automatizados em tempo real.
                          </p>
                        </div>
                      </div>
                    ) : activeReport ? (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="bg-[#161B22] border border-slate-800 rounded-2xl overflow-hidden shadow-xl"
                      >
                        {/* Top Profile Header */}
                        <div className="bg-slate-950/70 border-b border-slate-850 p-6 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider">
                              Análise Oficial Automatizada
                            </span>
                            <h2 className="text-2xl font-extrabold text-white tracking-tight">
                              Estudo de Risco: {activeReport.company}
                            </h2>
                          </div>
                          <span className="text-xs text-slate-500 font-medium font-mono flex items-center gap-1.5 self-start">
                            <Clock size={12} />
                            Gerado em:{" "}
                            {new Date(activeReport.createdAt).toLocaleString(
                              "pt-BR",
                            )}
                          </span>
                        </div>

                        {/* Content Grid */}
                        <div className="p-6 space-y-6">
                          {/* Gauge Risk Score Panel */}
                          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                            {/* Visual Score box */}
                            <div className="md:col-span-5 flex flex-col items-center justify-center p-6 rounded-xl bg-slate-950 border border-slate-850 text-center space-y-4">
                              <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                                Índice Geral de Risco
                              </span>

                              <div className="relative w-36 h-36 flex items-center justify-center">
                                {/* Semi SVG Track */}
                                <svg className="absolute inset-0 w-36 h-36 transform -rotate-90">
                                  <circle
                                    cx="72"
                                    cy="72"
                                    r="60"
                                    fill="transparent"
                                    stroke="#1e293b"
                                    strokeWidth="12"
                                  />
                                  <circle
                                    cx="72"
                                    cy="72"
                                    r="60"
                                    fill="transparent"
                                    stroke={
                                      getRiskColor(activeReport.riskScore)
                                        .progress === "bg-blue-400"
                                        ? "#3b82f6"
                                        : getRiskColor(activeReport.riskScore)
                                              .progress === "bg-amber-400"
                                          ? "#fbbf24"
                                          : "#f87171"
                                    }
                                    strokeWidth="12"
                                    strokeDasharray={2 * Math.PI * 60}
                                    strokeDashoffset={
                                      2 *
                                      Math.PI *
                                      60 *
                                      (1 - activeReport.riskScore / 100)
                                    }
                                    className="transition-all duration-1000 ease-out"
                                  />
                                </svg>

                                <div className="z-10 flex flex-col items-center justify-center">
                                  <span className="text-3xl font-extrabold text-white font-mono leading-none">
                                    {activeReport.riskScore}
                                    <span className="text-xs text-slate-400">
                                      %
                                    </span>
                                  </span>
                                  <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mt-1">
                                    Consolidado
                                  </span>
                                </div>
                              </div>

                              <div className="space-y-1">
                                <span
                                  className={`inline-block px-3 py-1 rounded text-xs font-bold font-mono tracking-wider uppercase ${getRiskColor(activeReport.riskScore).bg} ${getRiskColor(activeReport.riskScore).text}`}
                                >
                                  Risco{" "}
                                  {activeReport.riskScore < 30
                                    ? "Baixo/Seguro"
                                    : activeReport.riskScore < 65
                                      ? "Moderado"
                                      : "Alto/Alerta"}
                                </span>
                              </div>
                            </div>

                            {/* Short insight block */}
                            <div className="md:col-span-7 space-y-4">
                              <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 flex gap-3">
                                <Info
                                  size={18}
                                  className="text-blue-400 shrink-0 mt-0.5"
                                />
                                <div className="space-y-1">
                                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                                    Aviso de Conformidade
                                  </h4>
                                  <p className="text-xs text-slate-400 leading-relaxed">
                                    Esta análise computacional em tempo real foi
                                    moldada de acordo com o padrão do perfil do
                                    investidor e inteligência artificial da
                                    corporação Axion. Revise periodicamente
                                    relatórios trimestrais oficiais das
                                    companhias.
                                  </p>
                                </div>
                              </div>
                              <div className="flex justify-between items-center text-xs text-slate-400 p-2 font-mono">
                                <span>Mitigação do Risco: Ativa</span>
                                <span>Liquidez Estimada: Alta</span>
                              </div>
                            </div>
                          </div>

                          {/* Detailed Analysis in Fluid Portuguese */}
                          <div className="space-y-3">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2 flex items-center gap-2">
                              <Info size={16} className="text-blue-400" />
                              Leitura Econométrica e Tendências
                            </h3>
                            <div className="text-sm text-slate-300 leading-relaxed space-y-4 whitespace-pre-wrap font-sans bg-slate-950/25 p-4 rounded-xl">
                              {activeReport.analysis}
                            </div>
                          </div>

                          {/* Structured Recommendations */}
                          <div className="space-y-3 pt-2">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2 flex items-center gap-2">
                              <Bot size={16} className="text-blue-400" />
                              Parecer Técnico e Recomendações
                            </h3>
                            <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap font-sans bg-slate-950/25 p-4 rounded-xl">
                              {activeReport.recommendations}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-12 text-center flex flex-col items-center justify-center space-y-4">
                        <FileText size={48} className="text-slate-600" />
                        <div className="space-y-1">
                          <h3 className="text-sm font-bold text-white">
                            Nenhum Relatório Gerado Ainda
                          </h3>
                          <p className="text-xs text-slate-500 max-w-sm">
                            Use o buscador acima digitando o nome de uma empresa
                            ou seu ticker acionário para receber uma
                            interpretação econômica detalhada realizada pela
                            Invest-AI.
                          </p>
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}

                {/* 2. CHAT ASSISTANT INTERFACE */}
                {activeTab === "assistant" &&
                  (!isSubscribed ? (
                    <motion.div
                      key="assistant-paywall"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      <PaywallBanner onOpenSubscription={onOpenSubscription} />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="assistant-view"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="grid grid-cols-1 lg:grid-cols-12 gap-6"
                    >
                      {/* Chat Main Area */}
                      <div className="lg:col-span-8 flex flex-col h-[600px] bg-[#161B22] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
                        {/* Top Header */}
                        <div className="bg-slate-950/60 p-4 border-b border-slate-800 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                            <Bot size={16} />
                          </div>
                          <div>
                            <h3 className="text-sm font-bold text-white">
                              Conversa Inteligente de Mercado
                            </h3>
                            <p className="text-[10px] text-slate-400">
                              Analista Oficial da Axion para Dicas e
                              Esclarecimentos
                            </p>
                          </div>
                        </div>

                        {/* Chat Messages Log */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col-reverse">
                          {chats.length === 0 ? (
                            <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-3 mt-auto">
                              <Bot size={32} className="text-slate-600" />
                              <div className="space-y-1">
                                <p className="text-xs font-bold text-white">
                                  Sua Conversa Digital com a Invest-AI
                                </p>
                                <p className="text-[10px] text-slate-500 max-w-xs">
                                  Tire dúvidas de investimentos de forma
                                  objetiva, entenda as movimentações
                                  mercadológicas globais ou monte projeções.
                                </p>
                              </div>
                            </div>
                          ) : (
                            chats.map((chat) => (
                              <div key={chat.chatId} className="space-y-3 pt-2">
                                {/* User Msg */}
                                <div className="flex justify-end">
                                  <div className="bg-blue-600 text-white rounded-2xl rounded-tr-none px-4 py-2.5 max-w-[85%] text-xs font-semibold shadow-md leading-relaxed">
                                    {chat.message}
                                  </div>
                                </div>
                                {/* AI Response */}
                                <div className="flex justify-start items-start gap-2.5">
                                  <div className="w-6 h-6 rounded bg-slate-950 border border-slate-800 flex items-center justify-center text-blue-400 shrink-0 text-xs mt-1">
                                    <Bot size={12} />
                                  </div>
                                  <div className="bg-slate-950/80 text-slate-300 rounded-2xl rounded-tl-none px-4 py-2.5 max-w-[85%] text-xs shadow-md border border-slate-800/60 leading-relaxed whitespace-pre-wrap">
                                    {chat.response}
                                  </div>
                                </div>
                              </div>
                            ))
                          )}
                        </div>

                        {/* Input Actions Footer */}
                        <div className="bg-slate-950/60 p-4 border-t border-slate-800">
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={chatInput}
                              onChange={(e) => setChatInput(e.target.value)}
                              placeholder="Faça uma pergunta sobre o mercado financeiro... (Ex: Qual melhor aporte atual?)"
                              disabled={isChatLoading}
                              onKeyDown={(e) =>
                                e.key === "Enter" && handleSendChat()
                              }
                              className="flex-1 bg-[#0F1115] border border-slate-800 focus:border-blue-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none placeholder-slate-600 disabled:opacity-50"
                            />
                            <button
                              onClick={() => handleSendChat()}
                              disabled={isChatLoading || !chatInput.trim()}
                              id="send-chat-msg-btn"
                              className="p-2.5 rounded-xl bg-blue-600 text-white hover:bg-blue-500 disabled:opacity-50 cursor-pointer shrink-0 transition"
                            >
                              {isChatLoading ? (
                                <Loader2
                                  size={16}
                                  className="animate-spin text-white"
                                />
                              ) : (
                                <Send size={16} />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Chat suggestions and quick tips sidebar */}
                      <div className="lg:col-span-4 space-y-4">
                        {/* Recommendations sidebar */}
                        <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-4 space-y-4 shadow-xl">
                          <div className="space-y-1">
                            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                              Perguntas Recomendadas
                            </h4>
                            <p className="text-[10px] text-slate-500">
                              Clique para preencher e enviar automaticamente
                              para a Invest-AI.
                            </p>
                          </div>

                          <div className="space-y-2">
                            {CHAT_SUGGESTIONS.map((sug, i) => (
                              <button
                                key={i}
                                onClick={() => {
                                  handleSendChat(sug);
                                }}
                                className="w-full p-2.5 bg-[#0F1115] border border-slate-800 hover:border-slate-700 text-left text-xs rounded-xl text-slate-300 transition block text-ellipsis overflow-hidden whitespace-nowrap"
                              >
                                {sug}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Educational micro tip */}
                        <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-4 flex gap-3 items-start shadow-xl">
                          <Award
                            size={18}
                            className="text-blue-400 mt-0.5 shrink-0"
                          />
                          <div className="space-y-1">
                            <h5 className="text-[11px] font-bold text-white uppercase tracking-wider">
                              Anuência de Risco
                            </h5>
                            <p className="text-[10px] text-slate-400 leading-relaxed font-sans">
                              A Invest-AI foi desenhada de forma consultiva pela
                              corporação Axion para auxiliar investidores
                              individuais de acordo com os perfis descritos. Não
                              constitui ordem de compra direta de ativos.
                            </p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}

                {/* 3. FINANCIAL NEWS INTERFACE */}
                {activeTab === "news" &&
                  (!isSubscribed ? (
                    <motion.div
                      key="news-paywall"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      <PaywallBanner onOpenSubscription={onOpenSubscription} />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="news-view"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-6"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider px-1">
                          Notícias do Mercado Financeiro Global
                        </h3>
                        <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1.5 bg-[#161B22] border border-slate-800 px-2.5 py-1 rounded">
                          <RefreshCw
                            size={10}
                            className="text-blue-400 animate-spin"
                          />
                          Atualizado em Tempo Real
                        </span>
                      </div>

                      <div className="space-y-4">
                        {PRESET_NEWS.map((news) => (
                          <div
                            key={news.id}
                            className="bg-[#161B22] border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition duration-200 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                          >
                            <div className="space-y-2 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-slate-950 text-blue-400 border border-slate-800 font-mono">
                                  {news.category}
                                </span>
                                <span className="text-[10px] text-slate-500 font-medium">
                                  {news.source} • {news.time}
                                </span>
                              </div>
                              <h4 className="text-sm sm:text-base font-bold text-white tracking-tight">
                                {news.title}
                              </h4>
                              <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
                                {news.summary}
                              </p>
                            </div>

                            <div className="flex flex-col items-end gap-1.5 shrink-0 self-start md:self-center">
                              <span className="text-[9px] font-mono text-slate-500 uppercase">
                                Impacto Projetado
                              </span>
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase font-mono ${
                                  news.impact === "Alta"
                                    ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                    : news.impact === "Média"
                                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                      : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                }`}
                              >
                                {news.impact}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  ))}

                {/* 4. INDICADORES & MERCADO */}
                {activeTab === "indicadores" && (
                  <motion.div
                    key="indicadores-view"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    {/* Header row */}
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider px-1 flex items-center gap-2">
                        <Globe size={16} className="text-blue-400" />
                        Painel Global de Indicadores
                      </h3>
                      <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1.5 bg-[#161B22] border border-slate-800 px-2.5 py-1 rounded">
                        <Activity
                          size={10}
                          className="text-emerald-400 animate-pulse"
                        />
                        Dados Simulados em Tempo Real
                      </span>
                    </div>

                    {/* Indices Grid */}
                    <div>
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                        <BarChart size={13} />
                        Principais Índices Globais
                      </p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {MARKET_INDICES.map((idx) => (
                          <div
                            key={idx.name}
                            className="bg-[#161B22] border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                                {idx.region}
                              </span>
                              <span
                                className={`flex items-center gap-0.5 text-[10px] font-bold font-mono ${idx.up ? "text-emerald-400" : "text-rose-400"}`}
                              >
                                {idx.up ? (
                                  <ChevronUp size={12} />
                                ) : (
                                  <ChevronDown size={12} />
                                )}
                                {idx.change}
                              </span>
                            </div>
                            <p className="text-sm font-bold text-white">
                              {idx.name}
                            </p>
                            <p className="text-lg font-extrabold text-white font-mono mt-0.5">
                              {idx.value}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Currencies + Commodities */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Currencies */}
                      <div>
                        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                          <DollarSign size={13} />
                          Câmbio & Criptoativos
                        </p>
                        <div className="bg-[#161B22] border border-slate-800 rounded-2xl overflow-hidden">
                          {MARKET_CURRENCIES.map((cur, i) => (
                            <div
                              key={cur.pair}
                              className={`flex items-center justify-between px-4 py-3 ${i < MARKET_CURRENCIES.length - 1 ? "border-b border-slate-800/60" : ""}`}
                            >
                              <span className="text-sm font-bold text-white">
                                {cur.pair}
                              </span>
                              <div className="text-right">
                                <p className="text-sm font-extrabold text-white font-mono">
                                  {cur.value}
                                </p>
                                <p
                                  className={`text-[10px] font-bold font-mono flex items-center justify-end gap-0.5 ${cur.up ? "text-emerald-400" : "text-rose-400"}`}
                                >
                                  {cur.up ? (
                                    <ChevronUp size={10} />
                                  ) : (
                                    <ChevronDown size={10} />
                                  )}
                                  {cur.change}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Commodities */}
                      <div>
                        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                          <Flame size={13} />
                          Commodities Globais
                        </p>
                        <div className="bg-[#161B22] border border-slate-800 rounded-2xl overflow-hidden">
                          {MARKET_COMMODITIES.map((com, i) => (
                            <div
                              key={com.name}
                              className={`flex items-center justify-between px-4 py-3 ${i < MARKET_COMMODITIES.length - 1 ? "border-b border-slate-800/60" : ""}`}
                            >
                              <div>
                                <p className="text-sm font-bold text-white">
                                  {com.name}
                                </p>
                                <p className="text-[10px] text-slate-500 font-mono">
                                  {com.unit}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm font-extrabold text-white font-mono">
                                  {com.value}
                                </p>
                                <p
                                  className={`text-[10px] font-bold font-mono flex items-center justify-end gap-0.5 ${com.up ? "text-emerald-400" : "text-rose-400"}`}
                                >
                                  {com.up ? (
                                    <ChevronUp size={10} />
                                  ) : (
                                    <ChevronDown size={10} />
                                  )}
                                  {com.change}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Portfolio Allocation */}
                    <div>
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                        <Grid size={13} />
                        Alocação Sugerida de Portfólio — Perfil{" "}
                        {currentUser?.riskProfile === "conservative"
                          ? "Conservador"
                          : currentUser?.riskProfile === "aggressive"
                            ? "Arrojado"
                            : "Moderado"}
                      </p>
                      <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-5 space-y-4">
                        {/* Stacked bar */}
                        <div className="flex h-4 rounded-full overflow-hidden gap-0.5">
                          {PORTFOLIO_ALLOCATION.map((item) => (
                            <div
                              key={item.label}
                              className={`${item.color} transition-all duration-700`}
                              style={{ width: `${item.pct}%` }}
                              title={`${item.label}: ${item.pct}%`}
                            />
                          ))}
                        </div>
                        {/* Legend */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                          {PORTFOLIO_ALLOCATION.map((item) => (
                            <div
                              key={item.label}
                              className="flex items-center gap-2"
                            >
                              <div
                                className={`w-2.5 h-2.5 rounded-sm flex-shrink-0 ${item.color}`}
                              />
                              <div>
                                <p className="text-[11px] font-semibold text-slate-300">
                                  {item.label}
                                </p>
                                <p className="text-[10px] font-bold text-white font-mono">
                                  {item.pct}%
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                        <p className="text-[10px] text-slate-500 border-t border-slate-800 pt-3 leading-relaxed">
                          ⚠️ Alocação sugerida com base no perfil cadastrado.
                          Consulte sempre um assessor de investimentos
                          certificado antes de realizar aportes.
                        </p>
                      </div>
                    </div>

                    {/* Market Sentiment */}
                    <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-5">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Activity size={13} />
                        Sentimento Global do Mercado
                      </p>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        {[
                          {
                            label: "Medo Extremo",
                            pct: 15,
                            color:
                              "text-rose-400 bg-rose-500/10 border-rose-500/20",
                          },
                          {
                            label: "Neutro",
                            pct: 28,
                            color:
                              "text-amber-400 bg-amber-500/10 border-amber-500/20",
                          },
                          {
                            label: "Ganância",
                            pct: 57,
                            active: true,
                            color:
                              "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
                          },
                        ].map((s) => (
                          <div
                            key={s.label}
                            className={`rounded-xl p-4 border ${s.color}`}
                          >
                            <p className="text-2xl font-extrabold font-mono">
                              {s.pct}%
                            </p>
                            <p className="text-[11px] font-bold mt-1">
                              {s.label}
                            </p>
                          </div>
                        ))}
                      </div>
                      <p className="text-[10px] text-slate-500 mt-4 leading-relaxed">
                        Índice baseado em volume de negociações, volatilidade
                        implícita (VIX), momentum e dados de put/call ratio
                        globais. Atualizado a cada 15 minutos.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
