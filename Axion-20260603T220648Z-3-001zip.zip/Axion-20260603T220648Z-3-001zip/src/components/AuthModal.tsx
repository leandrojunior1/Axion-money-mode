import React, { useState, useEffect } from "react";
import { registerWithEmail, loginWithEmail } from "../services/auth";
import { saveUserProfile } from "../services/db";
import { X, Lock, Mail, User, ShieldAlert, ExternalLink } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import firebaseConfig from "../../firebase-applet-config.json";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: any) => void;
  initialTab?: "login" | "register";
}

export default function AuthModal({ isOpen, onClose, onSuccess, initialTab = "login" }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(initialTab === "login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [riskProfile, setRiskProfile] = useState<"conservative" | "moderate" | "aggressive">("moderate");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsLogin(initialTab === "login");
      setError(""); // Reset errors when opening/changing tab
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isLogin) {
        const user = await loginWithEmail(email, password);
        onSuccess(user);
        onClose();
      } else {
        if (!displayName.trim()) {
          throw new Error("Por favor, preencha o seu nome.");
        }
        const user = await registerWithEmail(email, password, displayName);
        // Create user profile in Database
        await saveUserProfile({
          userId: user.userId,
          email: user.email,
          displayName: user.displayName,
          createdAt: user.createdAt,
          riskProfile: riskProfile,
        });
        onSuccess({ ...user, riskProfile });
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || "Ocorreu um erro ao processar. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const isOperationNotAllowed = error.toLowerCase().includes("operation-not-allowed");

  return (
    <div id="auth-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-md overflow-hidden bg-[#161B22] border border-slate-800 rounded-2xl shadow-2xl"
      >
        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500" />

        <div className="p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white tracking-tight">
              {isLogin ? "Entrar na Axion" : "Criar uma Conta"}
            </h2>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              id="close-auth-btn"
            >
              <X size={18} />
            </button>
          </div>

          <p className="text-sm text-slate-400 mb-6 font-sans">
            {isLogin
              ? "Acesse nossa plataforma para usufruir da suite Invest-AI e relatórios analíticos em tempo real."
              : "Cadastre-se na Axion para começar a analisar tendências de empresas com relatórios inteligentes."}
          </p>

          {error && (
            <div className="flex flex-col gap-2.5 p-4 mb-5 text-xs text-rose-300 bg-rose-500/5 border border-rose-500/20 rounded-xl leading-relaxed">
              <div className="flex items-start gap-2">
                <ShieldAlert size={16} className="shrink-0 text-rose-400 mt-[1px]" />
                <span className="font-bold text-rose-400">
                  {isOperationNotAllowed ? "Ativação Necessária no Firebase" : "Erro de Autenticação"}
                </span>
              </div>
              
              {isOperationNotAllowed ? (
                <div className="space-y-3 text-slate-300 text-[11px] sm:text-xs">
                  <p>
                    O método de cadastro por <strong>E-mail e Senha</strong> precisa ser ativado no Console do Firebase de seu projeto.
                  </p>
                  
                  <div className="my-3">
                    <a
                      href={`https://console.firebase.google.com/project/${firebaseConfig.projectId}/authentication/providers`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 w-full text-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition shadow-md"
                    >
                      <span>Ativar E-mail/Senha no Firebase</span>
                      <ExternalLink size={14} />
                    </a>
                  </div>

                  <p className="font-semibold text-slate-200">Siga estes 3 passos simples:</p>
                  <ol className="list-decimal list-inside space-y-1.5 pl-1 leading-normal text-slate-400">
                    <li>Copie e acesse o link acima do console.</li>
                    <li>Ative o provedor de login <strong className="text-white">E-mail/senha</strong> (a primeira chave) e clique em <strong>Salvar</strong>.</li>
                    <li>Retorne para essa tela e tente se cadastrar novamente!</li>
                  </ol>
                </div>
              ) : (
                <span className="text-slate-300">{error}</span>
              )}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Nome Completo
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                    <User size={16} />
                  </span>
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Seu nome"
                    className="w-full pl-10 pr-4 py-2.5 text-sm text-white bg-[#0F1115] border border-slate-800 rounded-lg focus:outline-none focus:border-blue-500 transition"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Endereço de E-mail
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                  <Mail size={16} />
                </span>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="exemplo@empresa.com"
                  className="w-full pl-10 pr-4 py-2.5 text-sm text-white bg-[#0F1115] border border-slate-800 rounded-lg focus:outline-none focus:border-blue-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Senha de Acesso
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                  <Lock size={16} />
                </span>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 text-sm text-white bg-[#0F1115] border border-slate-800 rounded-lg focus:outline-none focus:border-blue-500 transition"
                />
              </div>
            </div>

            {!isLogin && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 font-sans">
                  Perfil de Investidor / Risco
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(["conservative", "moderate", "aggressive"] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRiskProfile(r)}
                      className={`py-2 text-xs font-bold rounded-lg border uppercase tracking-wider transition duration-150 ${
                        riskProfile === r
                          ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-500/10"
                          : "bg-[#0F1115] text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-300"
                      }`}
                    >
                      {r === "conservative" ? "Conservador" : r === "moderate" ? "Moderado" : "Arrojado"}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              id="auth-submit-btn"
              className="w-full py-3 mt-6 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 border border-blue-500/20 rounded-lg cursor-pointer transform hover:-translate-y-[1px] transition shadow-lg active:translate-y-0 disabled:opacity-50"
            >
              {loading ? "Aguarde..." : isLogin ? "Entrar na Suite" : "Registrar Conta"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsLogin(!isLogin);
                setError("");
              }}
              className="text-xs text-blue-400 hover:text-blue-300 hover:underline transition font-medium"
              id="auth-toggle-btn"
            >
              {isLogin ? "Não possui conta? Cadastre-se gratuitamente" : "Já é cadastrado? Faça o login na plataforma"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
