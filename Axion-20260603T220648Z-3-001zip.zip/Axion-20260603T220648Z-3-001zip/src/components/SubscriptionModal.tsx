import React, { useEffect, useState } from "react";
import { X, Zap, CheckCircle, Loader2, Star, Shield, Globe, Bot } from "lucide-react";
import { UserProfile } from "../types";

interface Plan {
  product_id: string;
  product_name: string;
  product_description: string;
  price_id: string;
  unit_amount: number;
  currency: string;
  recurring: { interval: string } | null;
}

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSubscribed?: () => void;
}

const FEATURES = [
  { icon: <Globe size={16} />, text: "Fluxo de notícias financeiras em tempo real" },
  { icon: <Bot size={16} />, text: "Acesso ao chatbot assistente Axion" },
  { icon: <Zap size={16} />, text: "Análises de risco ilimitadas" },
  { icon: <Star size={16} />, text: "Indicadores de mercado globais" },
  { icon: <Shield size={16} />, text: "Suporte prioritário Axion" },
];

function formatPrice(amount: number, currency: string) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: currency.toUpperCase(),
    minimumFractionDigits: 2,
  }).format(amount / 100);
}

export default function SubscriptionModal({
  isOpen,
  onClose,
  currentUser,
  onSubscribed,
}: SubscriptionModalProps) {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(true);
  const [checkingOut, setCheckingOut] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setLoadingPlans(true);
    fetch("/api/subscription/plans")
      .then((r) => r.json())
      .then((d) => setPlans(d.plans || []))
      .catch(() => setPlans([]))
      .finally(() => setLoadingPlans(false));
  }, [isOpen]);

  const handleCheckout = async (priceId: string) => {
    setCheckingOut(priceId);
    try {
      const res = await fetch("/api/subscription/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.userId,
          email: currentUser.email,
          priceId,
        }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      }
    } catch {
      setCheckingOut(null);
    }
  };

  if (!isOpen) return null;

  const monthly = plans.find((p) => p.recurring?.interval === "month");
  const yearly = plans.find((p) => p.recurring?.interval === "year");

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="w-full max-w-2xl bg-[#0F1115] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-blue-600/20 via-indigo-600/10 to-cyan-600/10 border-b border-slate-800 px-6 pt-6 pb-5">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[1px] w-64 bg-gradient-to-r from-blue-500/0 via-blue-400/80 to-blue-500/0" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X size={18} />
          </button>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
              <Zap size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-xs font-bold text-blue-400 uppercase tracking-widest">Axion</p>
              <h2 className="text-xl font-extrabold text-white">Assine o Plano PRO</h2>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Desbloqueie todo o potencial do Invest-AI com acesso completo à plataforma.
          </p>
        </div>

        <div className="p-6 grid md:grid-cols-2 gap-6">
          {/* Features */}
          <div className="space-y-4">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">
              Incluído no Axion PRO
            </p>
            <ul className="space-y-3">
              {FEATURES.map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-slate-300">
                  <span className="text-blue-400 flex-shrink-0">{f.icon}</span>
                  {f.text}
                </li>
              ))}
            </ul>
            <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-500">
              <Shield size={12} />
              Cancele a qualquer momento. Sem fidelidade.
            </div>
          </div>

          {/* Plans */}
          <div className="space-y-3">
            {loadingPlans ? (
              <div className="flex items-center justify-center h-32">
                <Loader2 size={24} className="animate-spin text-blue-400" />
              </div>
            ) : plans.length === 0 ? (
              <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 text-center text-xs text-slate-500">
                Planos em configuração. Tente novamente em breve.
              </div>
            ) : (
              <>
                {yearly && (
                  <div className="relative rounded-2xl border-2 border-blue-500/50 bg-blue-500/5 p-4">
                    <span className="absolute -top-3 left-4 px-2 py-0.5 bg-blue-600 text-white text-[10px] font-bold rounded-full uppercase tracking-wider">
                      Mais popular
                    </span>
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-sm font-bold text-white">Anual</p>
                        <p className="text-[11px] text-slate-400">Economize ~30%</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-extrabold text-white font-mono">
                          {formatPrice(yearly.unit_amount, yearly.currency)}
                        </p>
                        <p className="text-[10px] text-slate-400">/ano</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCheckout(yearly.price_id)}
                      disabled={!!checkingOut}
                      className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold transition disabled:opacity-60 flex items-center justify-center gap-2"
                    >
                      {checkingOut === yearly.price_id ? (
                        <><Loader2 size={14} className="animate-spin" /> Redirecionando...</>
                      ) : (
                        <>Assinar Anual <CheckCircle size={14} /></>
                      )}
                    </button>
                  </div>
                )}

                {monthly && (
                  <div className="rounded-2xl border border-slate-700 bg-slate-900/50 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-sm font-bold text-white">Mensal</p>
                        <p className="text-[11px] text-slate-400">Flexibilidade total</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-extrabold text-white font-mono">
                          {formatPrice(monthly.unit_amount, monthly.currency)}
                        </p>
                        <p className="text-[10px] text-slate-400">/mês</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCheckout(monthly.price_id)}
                      disabled={!!checkingOut}
                      className="w-full py-2.5 rounded-xl border border-slate-700 hover:border-slate-600 hover:bg-slate-800 text-white text-sm font-bold transition disabled:opacity-60 flex items-center justify-center gap-2"
                    >
                      {checkingOut === monthly.price_id ? (
                        <><Loader2 size={14} className="animate-spin" /> Redirecionando...</>
                      ) : (
                        "Assinar Mensal"
                      )}
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
