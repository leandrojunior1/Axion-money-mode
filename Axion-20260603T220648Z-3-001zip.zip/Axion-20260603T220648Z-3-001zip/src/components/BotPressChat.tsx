import { useEffect } from "react";

/**
 * BotPress Webchat Integration
 *
 * HOW TO CONFIGURE:
 * 1. Acesse https://app.botpress.cloud e crie uma conta gratuita
 * 2. Crie um novo bot e vá em "Integrations" > "Webchat"
 * 3. Copie o "Client ID" exibido na página de configuração do webchat
 * 4. Cole o valor abaixo em BOTPRESS_CLIENT_ID
 *
 * Exemplo:
 *   const BOTPRESS_CLIENT_ID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890";
 */
const BOTPRESS_CLIENT_ID = ""; // <- Cole seu Client ID do BotPress aqui

declare global {
  interface Window {
    botpressWebChat: {
      init: (config: Record<string, unknown>) => void;
      sendEvent: (event: { type: string }) => void;
    };
  }
}

export default function BotPressChat() {
  useEffect(() => {
    if (!BOTPRESS_CLIENT_ID) return;

    const injectScript = document.createElement("script");
    injectScript.src = "https://cdn.botpress.cloud/webchat/v2.2/inject.js";
    injectScript.async = true;

    injectScript.onload = () => {
      const configScript = document.createElement("script");
      configScript.src = `https://files.bpcloud.io/messaging/webchat/v2.2/inject.js`;
      configScript.async = true;
      document.body.appendChild(configScript);

      window.botpressWebChat.init({
        clientId: BOTPRESS_CLIENT_ID,
        hostUrl: "https://cdn.botpress.cloud/webchat/v2.2",
        messagingUrl: "https://messaging.botpress.cloud",
        botName: "Axion Assistant",
        avatarUrl: "",
        showPoweredBy: false,
        theme: "dark",
        themeColor: "#3B82F6",
        stylesheet:
          "https://cdn.botpress.cloud/webchat/v2.2/themes/prism.css",
      });
    };

    document.body.appendChild(injectScript);

    return () => {
      document.body.removeChild(injectScript);
      const existing = document.getElementById("bp-web-widget-container");
      if (existing) existing.remove();
    };
  }, []);

  return null;
}
