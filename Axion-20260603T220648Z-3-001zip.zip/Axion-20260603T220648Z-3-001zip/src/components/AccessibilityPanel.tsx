import React, { useState, useRef, useEffect } from "react";
import { useAccessibility, FontSize } from "../context/AccessibilityContext";
import {
  Accessibility,
  X,
  ZoomIn,
  ZoomOut,
  Type,
  Sun,
  Wind,
  BookOpen,
  RotateCcw,
} from "lucide-react";

export default function AccessibilityPanel() {
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const {
    fontSize,
    highContrast,
    reducedMotion,
    dyslexiaFont,
    setFontSize,
    setHighContrast,
    setReducedMotion,
    setDyslexiaFont,
  } = useAccessibility();

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  const fontSteps: FontSize[] = ["normal", "large", "xlarge"];
  const fontLabels: Record<FontSize, string> = {
    normal: "Normal",
    large: "Grande",
    xlarge: "Maior",
  };

  function increaseFontSize() {
    const idx = fontSteps.indexOf(fontSize);
    if (idx < fontSteps.length - 1) setFontSize(fontSteps[idx + 1]);
  }
  function decreaseFontSize() {
    const idx = fontSteps.indexOf(fontSize);
    if (idx > 0) setFontSize(fontSteps[idx - 1]);
  }

  function resetAll() {
    setFontSize("normal");
    setHighContrast(false);
    setReducedMotion(false);
    setDyslexiaFont(false);
  }

  const anyActive =
    fontSize !== "normal" || highContrast || reducedMotion || dyslexiaFont;

  return (
    <div
      ref={panelRef}
      className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3"
      role="region"
      aria-label="Painel de acessibilidade"
    >
      {open && (
        <div
          className="w-72 rounded-2xl border border-slate-700 bg-slate-900/95 backdrop-blur-md shadow-2xl shadow-black/50 overflow-hidden"
          role="dialog"
          aria-modal="false"
          aria-label="Opções de acessibilidade"
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Accessibility size={16} className="text-blue-400" />
              <span className="text-sm font-bold text-white">Acessibilidade</span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-slate-400 hover:text-white transition rounded-md p-0.5"
              aria-label="Fechar painel de acessibilidade"
            >
              <X size={16} />
            </button>
          </div>

          <div className="p-4 space-y-5">
            {/* Font Size */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Type size={14} className="text-slate-400" />
                <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Tamanho do Texto
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={decreaseFontSize}
                  disabled={fontSize === "normal"}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white hover:border-slate-600 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition text-xs font-medium"
                  aria-label="Diminuir tamanho da fonte"
                >
                  <ZoomOut size={14} />
                  Menor
                </button>

                <span className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs font-bold text-blue-400 min-w-[70px] text-center">
                  {fontLabels[fontSize]}
                </span>

                <button
                  onClick={increaseFontSize}
                  disabled={fontSize === "xlarge"}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white hover:border-slate-600 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition text-xs font-medium"
                  aria-label="Aumentar tamanho da fonte"
                >
                  <ZoomIn size={14} />
                  Maior
                </button>
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-3">
              <ToggleRow
                icon={<Sun size={14} />}
                label="Alto Contraste"
                description="Aumenta o contraste das cores"
                active={highContrast}
                onChange={setHighContrast}
                id="toggle-contrast"
              />
              <ToggleRow
                icon={<Wind size={14} />}
                label="Reduzir Movimento"
                description="Desativa animações e transições"
                active={reducedMotion}
                onChange={setReducedMotion}
                id="toggle-motion"
              />
              <ToggleRow
                icon={<BookOpen size={14} />}
                label="Fonte para Dislexia"
                description="Usa fonte de maior legibilidade"
                active={dyslexiaFont}
                onChange={setDyslexiaFont}
                id="toggle-dyslexia"
              />
            </div>

            {anyActive && (
              <button
                onClick={resetAll}
                className="w-full flex items-center justify-center gap-2 py-2 rounded-lg border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 hover:bg-slate-800 transition text-xs font-medium"
                aria-label="Restaurar configurações padrão de acessibilidade"
              >
                <RotateCcw size={12} />
                Restaurar padrões
              </button>
            )}
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen(!open)}
        className={`relative flex items-center justify-center w-12 h-12 rounded-full shadow-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 focus:ring-offset-slate-950 ${
          open
            ? "bg-blue-600 text-white shadow-blue-600/30"
            : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700 shadow-black/30"
        }`}
        aria-label={open ? "Fechar acessibilidade" : "Abrir opções de acessibilidade"}
        aria-expanded={open}
        aria-haspopup="dialog"
      >
        <Accessibility size={20} />
        {anyActive && !open && (
          <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-blue-500 border-2 border-slate-950" aria-hidden="true" />
        )}
      </button>
    </div>
  );
}

interface ToggleRowProps {
  icon: React.ReactNode;
  label: string;
  description: string;
  active: boolean;
  onChange: (v: boolean) => void;
  id: string;
}

function ToggleRow({ icon, label, description, active, onChange, id }: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-start gap-2 min-w-0">
        <span className={`mt-0.5 flex-shrink-0 ${active ? "text-blue-400" : "text-slate-500"}`}>
          {icon}
        </span>
        <div className="min-w-0">
          <label htmlFor={id} className="block text-xs font-semibold text-slate-200 cursor-pointer">
            {label}
          </label>
          <p className="text-[10px] text-slate-500 leading-tight">{description}</p>
        </div>
      </div>

      <button
        id={id}
        role="switch"
        aria-checked={active}
        onClick={() => onChange(!active)}
        className={`relative flex-shrink-0 w-10 h-5 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 focus:ring-offset-slate-900 ${
          active ? "bg-blue-600" : "bg-slate-700"
        }`}
        aria-label={label}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform duration-200 ${
            active ? "translate-x-5" : "translate-x-0"
          }`}
        />
      </button>
    </div>
  );
}
