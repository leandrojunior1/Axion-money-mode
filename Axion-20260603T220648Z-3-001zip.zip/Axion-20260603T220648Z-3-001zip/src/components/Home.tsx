import React from "react";
import { ServiceDetail } from "../types";
import {
  Code,
  TrendingUp,
  Cpu,
  BarChart,
  ArrowRight,
  Shield,
  Zap,
  CheckCircle,
} from "lucide-react";
import axionBanner from "../assets/images/axion_tech_banner_1780093072516.png";

interface HomeProps {
  setActiveTab: (tab: "home" | "invest-ai") => void;
  onOpenAuth: () => void;
  isLoggedIn: boolean;
}

const AXION_SERVICES: ServiceDetail[] = [
  {
    id: "invest-ai",
    title: "Invest-AI (Aplicações Financeiras Inteligentes)",
    description: "Nosso carro-chefe de inteligência corporativa. Um analista financeiro sênior rodado em IA para avaliar tendências de companhias em tempo real.",
    icon: "TrendingUp",
    details: [
      "Leitura e interpretação de tendências de companhias",
      "Geração automatizada de relatórios de risco instantâneos",
      "Sugestões analíticas de aportes para portfólios",
      "Acompanhamento de notícias do mercado financeiro global"
    ]
  },
  {
    id: "custom-software",
    title: "Softwares Corporativos Personalizados",
    description: "Desenvolvimento robusto e exclusivo de ponta a ponta. Planejamos e construímos o ecossistema ideal para as rotinas da sua empresa.",
    icon: "Code",
    details: [
      "Arquitetura modular em TypeScript e microsserviços",
      "Layouts responsivos, focados na experiência do usuário",
      "Sistemas de segurança ponta a ponta nativos",
      "APIs sob medida prontas para integrações ERP"
    ]
  },
  {
    id: "cloud-ops",
    title: "Infraestrutura em Nuvem Escalável",
    description: "Migração segura e arquitetura serverless. Seus sistemas hospedados com alta disponibilidade e otimização inteligente de recursos de custos.",
    icon: "Cpu",
    details: [
      "Implantação conteinerizada de alta performance",
      "Gerenciamento estruturado de banco de dados NoSQL",
      "Tolerância a falhas e backup incremental em nuvem",
      "Monitoramento ativo de vulnerabilidades digitais"
    ]
  },
  {
    id: "bi-analytics",
    title: "Analytics Avançado e BI de Alta Velocidade",
    description: "Decisões orientadas a dados estruturados de faturamento. Transforme silos de informação em dashboards interativos acionáveis.",
    icon: "BarChart",
    details: [
      "Cruzamento analítico de banco de dados internos",
      "Geração de relatórios automáticos em PDF/Markdown",
      "Interpretação estatística de desvios operacionais",
      "Acompanhamento de metas corporativas integradas"
    ]
  }
];

export default function Home({ setActiveTab, onOpenAuth, isLoggedIn }: HomeProps) {
  
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Code":
        return <Code size={24} className="text-blue-400" />;
      case "TrendingUp":
        return <TrendingUp size={24} className="text-blue-400" />;
      case "Cpu":
        return <Cpu size={24} className="text-blue-400" />;
      case "BarChart":
        return <BarChart size={24} className="text-blue-400" />;
      default:
        return <Code size={24} className="text-blue-400" />;
    }
  };

  return (
    <div className="bg-[#0F1115] text-slate-300 flex flex-col min-h-screen font-sans">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 lg:py-24 border-b border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(37,99,235,0.07),transparent)]" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Texts */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-semibold text-blue-400 bg-blue-500/10 border border-blue-500/15 rounded-full uppercase tracking-widest animate-pulse">
                <Zap size={12} />
                Soluções Digitais Sob Medida
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-none">
                Softwares Corporativos <br />
                <span className="bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-400 bg-clip-text text-transparent">
                  Personalizados & Inteligentes
                </span>
              </h1>
              <p className="text-base sm:text-lg text-slate-400 leading-relaxed max-w-2xl">
                Projetamos sistemas modernos, de alta segurança e prontos para escalar. Como o carro-chefe da nossa corporação, o <strong className="text-white font-semibold font-sans">Invest-AI</strong> oferece às empresas uma suite robusta de interpretação de tendências, detecção de riscos financeiros e inteligência de mercado em tempo real.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <button
                  onClick={() => setActiveTab("invest-ai")}
                  className="px-6 py-3.5 text-sm font-semibold rounded-xl text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 shadow-xl shadow-blue-500/15 cursor-pointer transform hover:-translate-y-0.5 transition flex items-center justify-center gap-2 font-sans"
                  id="hero-investai-callout"
                >
                  Conhecer Invest-AI (Flagship)
                  <ArrowRight size={16} />
                </button>
                <button
                  onClick={() => {
                    document.getElementById("servicos")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="px-6 py-3.5 text-sm font-semibold rounded-xl text-white bg-slate-900 border border-slate-800 hover:bg-slate-850 cursor-pointer transition flex items-center justify-center"
                  id="hero-services-anchor"
                >
                  Ver Todos os Serviços
                </button>
              </div>

              {/* Badges row */}
              <div className="flex flex-wrap items-center gap-6 text-xs text-slate-500 pt-6">
                <span className="flex items-center gap-1.5 font-medium">
                  <Shield size={14} className="text-blue-400" />
                  Arquitetura de Segurança Bancária
                </span>
                <span className="flex items-center gap-1.5 font-medium">
                  <CheckCircle size={14} className="text-blue-400" />
                  Conformidade e Sigilo Absoluto
                </span>
              </div>
            </div>

            {/* Right Images banner - Mockup styled */}
            <div className="lg:col-span-5 relative mt-8 lg:mt-0">
              <div className="relative border border-slate-800 rounded-3xl overflow-hidden shadow-2xl bg-[#161B22] p-2 transform hover:scale-[1.01] transition duration-300">
                <div className="absolute top-4 left-4 flex gap-1.5 z-10">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-blue-500/80" />
                </div>
                <img
                  src={axionBanner}
                  alt="Axion Technology Platform"
                  referrerPolicy="no-referrer"
                  className="w-full rounded-2xl border border-slate-950 shadow-inner"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-cyan-550/10 rounded-full blur-3xl -z-10" />
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-blue-550/10 rounded-full blur-3xl -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicos" className="py-20 relative border-b border-slate-800">
        <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-[#0F1115]/20 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-xs font-bold text-blue-400 uppercase tracking-widest">
              Nossas Soluções Corporativas
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Sistemas Digitais Construídos com Engenharia de Ponta
            </p>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              Trabalhamos de forma ágil para criar produtos de alto retorno técnico e de design inovador. Nossa missão é acelerar operações por meio da tecnologia.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {AXION_SERVICES.map((srv) => (
              <div
                key={srv.id}
                id={`srv-card-${srv.id}`}
                className={`relative flex flex-col justify-between p-6 rounded-2xl border transition duration-350 bg-[#161B22]/50 hover:bg-[#161B22] ${
                  srv.id === "invest-ai"
                    ? "border-blue-500/30 ring-1 ring-blue-500/10 shadow-lg shadow-blue-500/5"
                    : "border-slate-800 hover:border-slate-700"
                }`}
              >
                {srv.id === "invest-ai" && (
                  <span className="absolute -top-3.5 right-6 px-3 py-1 text-[10px] font-bold text-white bg-blue-600 rounded-full uppercase tracking-wider shadow-md">
                    PRODUTO CARRO-CHEFE
                  </span>
                )}

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-[#0F1115] border border-slate-800 rounded-xl">
                      {getIcon(srv.icon)}
                    </div>
                    <h3 className="text-lg font-bold text-white tracking-tight">{srv.title}</h3>
                  </div>

                  <p className="text-sm text-slate-400 leading-relaxed">{srv.description}</p>

                  <ul className="space-y-2 pt-2">
                    {srv.details.map((detail, index) => (
                      <li key={index} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle size={14} className="text-blue-400 shrink-0 mt-[1px]" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 pt-4 border-t border-slate-800/60">
                  {srv.id === "invest-ai" ? (
                    <button
                      onClick={() => setActiveTab("invest-ai")}
                      className="inline-flex items-center gap-2 text-xs font-bold text-blue-400 hover:text-blue-300 group cursor-pointer"
                    >
                      Acessar Suite Invest-AI Completa
                      <ArrowRight size={12} className="group-hover:translate-x-1 transition" />
                    </button>
                  ) : (
                    <span className="text-xs text-slate-500 font-medium italic">
                      Disponível sob consulta comercial na corporação Axion
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Corporate trust section */}
      <section className="py-16 bg-[#0F1115]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#161B22]/40 border border-slate-800 rounded-3xl p-8 sm:p-12 relative overflow-hidden">
            <div className="absolute -bottom-10 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-8 space-y-4">
                <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  Pronto para estruturar sua inteligência competitiva com a Axion?
                </h3>
                <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-xl">
                  Seja criando portais internos robustos, otimizando fluxos de nuvem ou testando o <strong className="text-white font-medium">Invest-AI</strong>, nossos engenheiros especialistas estão de prontidão para desenhar a solução ideal de crescimento.
                </p>
              </div>
              <div className="lg:col-span-4 flex justify-start lg:justify-end">
                {isLoggedIn ? (
                  <button
                    onClick={() => setActiveTab("invest-ai")}
                    className="px-6 py-3 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 border border-blue-500/20 rounded-xl cursor-pointer transition shadow-lg shadow-blue-600/15"
                  >
                    Acessar Meu Painel de IA
                  </button>
                ) : (
                  <button
                    onClick={onOpenAuth}
                    className="px-6 py-3 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 border border-blue-500/20 rounded-xl cursor-pointer transition shadow-lg shadow-blue-600/15"
                  >
                    Iniciar Teste Corporativo Grátis
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 border-t border-slate-800 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <p>© {new Date().getFullYear()} Axion Software Solutions LTDA. Todos os direitos reservados.</p>
          </div>
          <div className="flex gap-6">
            <span className="hover:text-slate-300 cursor-pointer">Termos de Uso</span>
            <span className="hover:text-slate-300 cursor-pointer">Privacidade Protegida</span>
            <span className="hover:text-slate-300 cursor-pointer">Suporte Corporativo</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
