import React, { useState } from "react";
import { UserProfile } from "../types";
import { logoutUser } from "../services/auth";
import { Layers, Menu, X, LogOut, Shield, ChevronDown, Award, Crown, Zap } from "lucide-react";

interface NavbarProps {
  currentUser: UserProfile | null;
  onOpenAuth: (tab?: "login" | "register") => void;
  activeTab: "home" | "invest-ai";
  setActiveTab: (tab: "home" | "invest-ai") => void;
  onLogout: () => void;
  isSubscribed?: boolean;
  onManageSubscription?: () => void;
  onOpenSubscription?: () => void;
}

export default function Navbar({
  currentUser,
  onOpenAuth,
  activeTab,
  setActiveTab,
  onLogout,
  isSubscribed = false,
  onManageSubscription,
  onOpenSubscription,
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const handleLogout = async () => {
    await logoutUser();
    onLogout();
    setProfileDropdownOpen(false);
  };

  const riskLabel = (r?: "conservative" | "moderate" | "aggressive") => {
    if (!r) return "Moderado";
    if (r === "conservative") return "Conservador";
    if (r === "moderate") return "Moderado";
    return "Arrojado";
  };

  return (
    <nav className="sticky top-0 z-40 bg-[#0F1115]/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab("home")}>
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-white shadow-lg shadow-blue-500/10">
              <Layers size={18} className="stroke-[2.5px]" />
              <div className="absolute -bottom-0.5 -right-0.5 w-2 py-0.5 h-2 bg-white rounded-full ring-2 ring-slate-950" />
            </div>
            <span className="text-xl font-extrabold text-white tracking-wider font-sans uppercase">
              AXION
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => setActiveTab("home")}
              className={`text-sm font-semibold tracking-wide transition relative py-1 ${
                activeTab === "home" ? "text-blue-400 font-bold" : "text-slate-400 hover:text-white"
              }`}
              id="nav-home-btn"
            >
              Início
              {activeTab === "home" && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-blue-500 rounded-full" />
              )}
            </button>
            <button
              onClick={() => {
                setActiveTab("home");
                setTimeout(() => {
                  document.getElementById("servicos")?.scrollIntoView({ behavior: "smooth" });
                }, 100);
              }}
              className="text-sm font-semibold tracking-wide text-slate-400 hover:text-white transition"
              id="nav-services-btn"
            >
              Nossos Serviços
            </button>
            <button
              onClick={() => setActiveTab("invest-ai")}
              className={`text-sm font-semibold tracking-wide transition relative py-1 flex items-center gap-1.5 ${
                activeTab === "invest-ai" ? "text-blue-400 font-bold" : "text-slate-400 hover:text-white"
              }`}
              id="nav-investai-btn"
            >
              <Award size={14} className="text-blue-400 animate-pulse" />
              Invest-AI
              <span className="px-1.5 py-0.5 text-[8px] font-bold text-blue-950 bg-blue-400 rounded-full leading-none">
                PRO
              </span>
              {activeTab === "invest-ai" && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-blue-500 rounded-full" />
              )}
            </button>
          </div>

          {/* Desktop Auth State */}
          <div className="hidden md:flex items-center gap-4">
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-white bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-lg transition"
                  id="profile-dropdown-trigger"
                >
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-xs font-bold font-mono">
                    {currentUser.displayName.charAt(0).toUpperCase()}
                  </div>
                  <span>{currentUser.displayName.split(" ")[0]}</span>
                  <ChevronDown size={14} className="text-slate-400" />
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-60 rounded-xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden py-1">
                    <div className="px-4 py-3 border-b border-slate-800/60">
                      <p className="text-xs text-slate-500">Usuário Autenticado</p>
                      <p className="text-sm font-bold text-white truncate">{currentUser.displayName}</p>
                      <p className="text-xs text-slate-400 truncate">{currentUser.email}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex items-center gap-1 px-2 py-0.5 w-fit rounded bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-400 font-bold tracking-wide uppercase">
                          <Shield size={10} />
                          Perfil: {riskLabel(currentUser.riskProfile)}
                        </div>
                        {isSubscribed && (
                          <div className="flex items-center gap-1 px-2 py-0.5 w-fit rounded bg-emerald-500/10 border border-emerald-500/20 text-[10px] text-emerald-400 font-bold tracking-wide uppercase">
                            <Crown size={10} />
                            PRO
                          </div>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => { setProfileDropdownOpen(false); onManageSubscription?.(); }}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-semibold hover:bg-slate-800 transition text-left"
                    >
                      {isSubscribed ? (
                        <>
                          <Crown size={14} className="text-emerald-400" />
                          <span className="text-emerald-400">Gerenciar Assinatura PRO</span>
                        </>
                      ) : (
                        <>
                          <Zap size={14} className="text-blue-400" />
                          <span className="text-blue-400">Assinar Axion PRO</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2 px-4 py-2 text-xs text-rose-400 hover:text-rose-300 hover:bg-slate-800 transition text-left border-t border-slate-800/60"
                      id="logout-btn"
                    >
                      <LogOut size={14} />
                      Sair da plataforma
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onOpenAuth("login")}
                  className="text-xs font-bold text-slate-300 hover:text-white transition px-4 py-2"
                  id="navbar-login-btn"
                >
                  Entrar
                </button>
                <button
                  onClick={() => onOpenAuth("register")}
                  className="text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 border border-blue-500/20 rounded-lg px-4 py-2 transition shadow-lg shadow-blue-600/15"
                  id="navbar-register-btn"
                >
                  Cadastrar-se
                </button>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Menu */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-400 hover:text-white transition"
              id="mobile-menu-toggle"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden bg-[#0F1115] border-b border-slate-800 px-4 pt-2 pb-4 space-y-3">
          <button
            onClick={() => {
              setActiveTab("home");
              setIsOpen(false);
            }}
            className={`block w-full text-left py-2 font-semibold tracking-wide ${
              activeTab === "home" ? "text-blue-400" : "text-slate-400"
            }`}
          >
            Início
          </button>
          <button
            onClick={() => {
              setActiveTab("home");
              setIsOpen(false);
              setTimeout(() => {
                document.getElementById("servicos")?.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}
            className="block w-full text-left py-2 text-slate-400 font-semibold"
          >
            Nossos Serviços
          </button>
          <button
            onClick={() => {
              setActiveTab("invest-ai");
              setIsOpen(false);
            }}
            className={`w-full text-left py-2 font-semibold flex items-center gap-2 ${
              activeTab === "invest-ai" ? "text-blue-400" : "text-slate-400"
            }`}
          >
            <Award size={14} className="text-blue-400" />
            Invest-AI
            <span className="px-1.5 py-0.5 text-[8px] font-bold text-blue-950 bg-blue-400 rounded-full leading-none">
              PRO
            </span>
          </button>

          <div className="pt-4 border-t border-slate-800">
            {currentUser ? (
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-500">Logado como</p>
                  <p className="text-sm font-bold text-white">{currentUser.displayName}</p>
                  <p className="text-xs text-slate-400">{currentUser.email}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="inline-block text-[10px] font-bold text-blue-400 uppercase tracking-widest bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded">
                      Perfil: {riskLabel(currentUser.riskProfile)}
                    </span>
                    {isSubscribed && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 uppercase tracking-widest bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                        <Crown size={9} /> PRO
                      </span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => { setIsOpen(false); onManageSubscription?.(); }}
                  className={`w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border transition ${
                    isSubscribed
                      ? "text-emerald-400 bg-emerald-500/5 border-emerald-500/15 hover:bg-emerald-500/10"
                      : "text-blue-400 bg-blue-500/5 border-blue-500/15 hover:bg-blue-500/10"
                  }`}
                >
                  {isSubscribed ? <><Crown size={14} /> Gerenciar Assinatura</> : <><Zap size={14} /> Assinar Axion PRO</>}
                </button>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-rose-400 bg-rose-500/5 border border-rose-500/15 rounded-lg hover:bg-rose-500/10 transition"
                  id="mobile-logout-btn"
                >
                  <LogOut size={14} />
                  Sair do sistema
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    onOpenAuth("login");
                    setIsOpen(false);
                  }}
                  className="w-full py-2.5 text-xs text-center font-bold text-slate-300 border border-slate-800 rounded-lg hover:border-slate-700 transition"
                >
                  Entrar
                </button>
                <button
                  onClick={() => {
                    onOpenAuth("register");
                    setIsOpen(false);
                  }}
                  className="w-full py-2.5 text-xs text-center font-bold text-white bg-blue-600 rounded-lg transition"
                >
                  Cadastrar
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
