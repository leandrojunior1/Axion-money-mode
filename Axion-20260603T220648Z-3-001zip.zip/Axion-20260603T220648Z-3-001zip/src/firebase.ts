import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

let app;
let dbInstance: any = null;
let authInstance: any = null;
let useFirebaseBackend = false;

// Check if Firebase is actually configured with active values
if (
  firebaseConfig &&
  firebaseConfig.apiKey &&
  firebaseConfig.apiKey !== "PLACEHOLDER_KEY" &&
  firebaseConfig.projectId !== "placeholder-project"
) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    dbInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    authInstance = getAuth(app);
    useFirebaseBackend = true;
    console.log("Firebase initialized successfully with config.");
  } catch (error) {
    console.error("Failed to initialize Firebase with real config:", error);
  }
} else {
  console.log("Using local database and authentication (Firebase not provisioned).");
}

export const isRealFirebase = useFirebaseBackend;
export const db = dbInstance;
export const auth = authInstance;

// Helper to check standard connection to Firestore as requested by the skill
if (useFirebaseBackend && dbInstance) {
  import("firebase/firestore").then(async ({ doc, getDocFromServer }) => {
    try {
      await getDocFromServer(doc(dbInstance, "test", "connection"));
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.includes("the client is offline")
      ) {
        console.error("Please check your Firebase configuration. Client is offline.");
      }
    }
  });
}

// Error logger conformant to the Firestore custom error schema requested by the skill
export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
) {
  const currentUser = authInstance?.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentUser?.uid || null,
      email: currentUser?.email || null,
      emailVerified: currentUser?.emailVerified || null,
      isAnonymous: currentUser?.isAnonymous || null,
      tenantId: currentUser?.tenantId || null,
      providerInfo:
        currentUser?.providerData?.map((provider: any) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
