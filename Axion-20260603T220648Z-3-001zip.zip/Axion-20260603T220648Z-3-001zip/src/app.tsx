import React, { useState, useEffect } from "react";
import { UserProfile } from "./types";
import { subscribeToAuth } from "./services/auth";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import InvestAI from "./components/InvestAI";
import AuthModal from "./components/AuthModal";
import AccessibilityPanel from "./components/AccessibilityPanel";
import { AccessibilityProvider } from "./context/AccessibilityContext";
import BotPressChat from "./components/BotPressChat";
import SubscriptionModal from "./components/SubscriptionModal";
import SubscriptionManager from "./components/SubscriptionManager";
import { useSubscription } from "./hooks/useSubscription";

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<"home" | "invest-ai">("home");
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(true);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isSubscriptionManagerOpen, setIsSubscriptionManagerOpen] = useState(false);

  const { active: isSubscribed, loading: subscriptionLoading, refetch: refetchSubscription } = useSubscription(currentUser?.userId ?? null);

  useEffect(() => {
    const unsubscribe = subscribeToAuth((profile) => {
      setCurrentUser(profile);
      setLoading(false);
    });
    return () => {
      if (typeof unsubscribe === "function") unsubscribe();
    };
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("subscribed") === "true") {
      refetchSubscription();
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  const handleOpenAuthModal = (tab: "login" | "register" = "login") => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const handleOpenSubscription = () => {
    if (!currentUser) {
      handleOpenAuthModal("register");
      return;
    }
    setIsSubscriptionModalOpen(true);
  };

  const handleManageSubscription = () => {
    if (!currentUser) {
      handleOpenAuthModal("login");
      return;
    }
    setIsSubscriptionManagerOpen(true);
  };

  if (loading) {
    return (
      <AccessibilityProvider>
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-950 text-white">
          <div className="w-12 h-12 rounded-full border-t-2 border-emerald-400 border-r-2 border-r-transparent animate-spin" />
          <p className="mt-4 text-xs font-semibold text-slate-400 uppercase tracking-widest font-mono">
            Carregando Workspace Axion ...
          </p>
        </div>
      </AccessibilityProvider>
    );
  }

  return (
    <AccessibilityProvider>
      <div className="flex flex-col min-h-screen bg-slate-950 font-sans antialiased text-slate-200">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[999] focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-lg focus:font-bold focus:text-sm"
        >
          Pular para o conteúdo principal
        </a>

        <Navbar
          currentUser={currentUser}
          onOpenAuth={handleOpenAuthModal}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onLogout={() => setCurrentUser(null)}
          isSubscribed={isSubscribed}
          onManageSubscription={handleManageSubscription}
          onOpenSubscription={handleOpenSubscription}
        />

        <main id="main-content" className="flex-1" tabIndex={-1}>
          {activeTab === "home" ? (
            <Home
              setActiveTab={setActiveTab}
              onOpenAuth={handleOpenAuthModal}
              isLoggedIn={!!currentUser}
            />
          ) : (
            <InvestAI
              currentUser={currentUser}
              onOpenAuth={handleOpenAuthModal}
              isSubscribed={isSubscribed}
              subscriptionLoading={subscriptionLoading}
              onOpenSubscription={handleOpenSubscription}
            />
          )}
        </main>

        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={(profile) => setCurrentUser(profile)}
          initialTab={authModalTab}
        />

        {currentUser && (
          <SubscriptionModal
            isOpen={isSubscriptionModalOpen}
            onClose={() => setIsSubscriptionModalOpen(false)}
            currentUser={currentUser}
            onSubscribed={refetchSubscription}
          />
        )}

        {currentUser && (
          <SubscriptionManager
            isOpen={isSubscriptionManagerOpen}
            onClose={() => setIsSubscriptionManagerOpen(false)}
            currentUser={currentUser}
            isSubscribed={isSubscribed}
            onOpenSubscription={handleOpenSubscription}
          />
        )}

        <AccessibilityPanel />
        {isSubscribed && <BotPressChat />}
      </div>
    </AccessibilityProvider>
  );
}
