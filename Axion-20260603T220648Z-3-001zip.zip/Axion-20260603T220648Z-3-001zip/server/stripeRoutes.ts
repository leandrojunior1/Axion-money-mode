import { Router } from 'express';
import { getUncachableStripeClient } from './stripeClient';
import { Pool } from 'pg';

const router = Router();

function getPool() {
  return new Pool({ connectionString: process.env.DATABASE_URL });
}

async function getOrCreateCustomer(userId: string, email: string): Promise<string> {
  const pool = getPool();
  try {
    const { rows } = await pool.query(
      'SELECT stripe_customer_id FROM axion_users WHERE user_id = $1',
      [userId]
    );
    if (rows[0]?.stripe_customer_id) return rows[0].stripe_customer_id;

    const stripe = await getUncachableStripeClient();
    const customer = await stripe.customers.create({ email, metadata: { userId } });

    await pool.query(
      `INSERT INTO axion_users (user_id, email, stripe_customer_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id) DO UPDATE SET stripe_customer_id = $3`,
      [userId, email, customer.id]
    );
    return customer.id;
  } finally {
    await pool.end();
  }
}

router.get('/api/subscription/status', async (req: any, res) => {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId required' });

  const pool = getPool();
  try {
    const { rows } = await pool.query(
      'SELECT stripe_subscription_id FROM axion_users WHERE user_id = $1',
      [userId]
    );
    const subId = rows[0]?.stripe_subscription_id;
    if (!subId) return res.json({ active: false, subscription: null });

    const { rows: subRows } = await pool.query(
      `SELECT status FROM stripe.subscriptions WHERE id = $1`,
      [subId]
    );
    const status = subRows[0]?.status;
    res.json({ active: status === 'active' || status === 'trialing', status });
  } catch (e: any) {
    res.json({ active: false, subscription: null });
  } finally {
    await pool.end();
  }
});

router.get('/api/subscription/plans', async (_req, res) => {
  const pool = getPool();
  try {
    const { rows } = await pool.query(`
      SELECT
        p.id as product_id,
        p.name as product_name,
        p.description as product_description,
        pr.id as price_id,
        pr.unit_amount,
        pr.currency,
        pr.recurring
      FROM stripe.products p
      JOIN stripe.prices pr ON pr.product = p.id AND pr.active = true
      WHERE p.active = true
      ORDER BY pr.unit_amount ASC
    `);
    res.json({ plans: rows });
  } catch (e: any) {
    res.json({ plans: [] });
  } finally {
    await pool.end();
  }
});

router.post('/api/subscription/checkout', async (req: any, res) => {
  const { userId, email, priceId } = req.body;
  if (!userId || !email || !priceId) {
    return res.status(400).json({ error: 'userId, email, priceId required' });
  }

  try {
    const customerId = await getOrCreateCustomer(userId, email);
    const stripe = await getUncachableStripeClient();

    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers['x-forwarded-host'] || req.get('host');
    const base = `${protocol}://${host}`;

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: 'subscription',
      success_url: `${base}/?subscribed=true`,
      cancel_url: `${base}/?canceled=true`,
    });

    res.json({ url: session.url });
  } catch (e: any) {
    console.error('Checkout error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

router.post('/api/subscription/portal', async (req: any, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ error: 'userId required' });

  const pool = getPool();
  try {
    const { rows } = await pool.query(
      'SELECT stripe_customer_id FROM axion_users WHERE user_id = $1',
      [userId]
    );
    const customerId = rows[0]?.stripe_customer_id;
    if (!customerId) return res.status(404).json({ error: 'No customer found' });

    const stripe = await getUncachableStripeClient();
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers['x-forwarded-host'] || req.get('host');

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${protocol}://${host}/`,
    });

    res.json({ url: portalSession.url });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  } finally {
    await pool.end();
  }
});

export default router;
