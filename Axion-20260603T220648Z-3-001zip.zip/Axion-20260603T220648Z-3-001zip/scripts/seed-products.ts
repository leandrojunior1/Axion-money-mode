import { getUncachableStripeClient } from '../server/stripeClient';

async function createProducts() {
  try {
    const stripe = await getUncachableStripeClient();
    console.log('Criando produtos no Stripe...');

    const existing = await stripe.products.search({
      query: "name:'Axion PRO' AND active:'true'"
    });

    if (existing.data.length > 0) {
      console.log('Produto Axion PRO já existe:', existing.data[0].id);
      const prices = await stripe.prices.list({ product: existing.data[0].id, active: true });
      prices.data.forEach(p => console.log(`  Preço: ${p.id} - ${p.unit_amount! / 100} ${p.currency}/${(p.recurring as any)?.interval}`));
      return;
    }

    const product = await stripe.products.create({
      name: 'Axion PRO',
      description: 'Acesso completo ao Invest-AI: Notícias do mercado em tempo real, chatbot assistente e análises ilimitadas.',
    });
    console.log(`Produto criado: ${product.name} (${product.id})`);

    const monthly = await stripe.prices.create({
      product: product.id,
      unit_amount: 2990,
      currency: 'brl',
      recurring: { interval: 'month' },
    });
    console.log(`Preço mensal: R$ 29,90/mês (${monthly.id})`);

    const yearly = await stripe.prices.create({
      product: product.id,
      unit_amount: 24900,
      currency: 'brl',
      recurring: { interval: 'year' },
    });
    console.log(`Preço anual: R$ 249,00/ano (${yearly.id})`);

    console.log('\n✓ Produtos criados com sucesso!');
  } catch (e: any) {
    console.error('Erro:', e.message);
    process.exit(1);
  }
}

createProducts();
