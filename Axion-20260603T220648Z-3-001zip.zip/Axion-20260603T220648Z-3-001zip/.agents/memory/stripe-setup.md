---
name: Stripe Setup Status
description: Stripe paywall built but not yet connected to a live Stripe account
---

## Status
- `stripe` + `stripe-replit-sync` npm packages installed
- Full server routes at `server/stripeRoutes.ts` (subscription status, plans, checkout, portal)
- Stripe client at `server/stripeClient.ts` using Replit connector API
- Webhook handler at `server/webhookHandlers.ts`
- Seed script at `scripts/seed-products.ts` (creates "Axion PRO" product in BRL)
- Frontend paywall: `src/components/SubscriptionModal.tsx`, `src/hooks/useSubscription.ts`
- `axion_users` table created in PostgreSQL (user_id, email, stripe_customer_id, stripe_subscription_id)
- Paywall gates: "Notícias" tab + "Assistente Virtual" tab + BotPressChat widget

## To activate payments
1. Create Stripe account at stripe.com (free)
2. Get sk_test_ / pk_test_ keys from dashboard.stripe.com/apikeys
3. Connect via Replit Integrations tab OR store STRIPE_SECRET_KEY / STRIPE_PUBLISHABLE_KEY as secrets
4. Run `npx tsx scripts/seed-products.ts` to create Axion PRO product
5. For publishing: use pk_live_ / sk_live_ keys in Replit Publish pane

**Why:** App currently runs in graceful no-Stripe mode — paywall shows visually, payments don't process.
