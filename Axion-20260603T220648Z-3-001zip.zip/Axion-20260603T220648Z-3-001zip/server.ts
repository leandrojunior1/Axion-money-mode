import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { runMigrations } from "stripe-replit-sync";
import { Pool } from "pg";

dotenv.config();

const app = express();
const PORT = 5000;

// ─── Stripe webhook MUST be registered BEFORE express.json() ───
app.post(
  "/api/stripe/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const signature = req.headers["stripe-signature"];
    if (!signature) return res.status(400).json({ error: "Missing signature" });
    try {
      const { WebhookHandlers } = await import("./server/webhookHandlers");
      const sig = Array.isArray(signature) ? signature[0] : signature;
      await WebhookHandlers.processWebhook(req.body as Buffer, sig);
      res.status(200).json({ received: true });
    } catch (e: any) {
      console.error("Webhook error:", e.message);
      res.status(400).json({ error: "Webhook error" });
    }
  }
);

app.use(express.json());

// ─── Stripe routes ───
import("./server/stripeRoutes").then(({ default: stripeRoutes }) => {
  app.use(stripeRoutes);
});

// ─── AI Client ───
const apiKey = process.env.GEMINI_API_KEY || "";
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!apiKey) console.warn("WARNING: GEMINI_API_KEY not set.");
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { "User-Agent": "aistudio-build" } },
    });
  }
  return aiClient;
}

// ─── Health ───
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

// ─── Chat ───
app.post("/api/invest-ai/chat", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Mensagem é obrigatória." });

    const ai = getAiClient();
    const systemPrompt = `Você é o Invest-AI, o assistente virtual inteligente oficial da empresa Axion para o mercado financeiro.
Sua especialidade é dar dicas de investimentos de forma objetiva, ler e interpretar tendências corporativas, e orientar com inteligência sobre riscos.
Seu tom de voz deve ser elegante, analítico, seguro e profissional.
Responda sempre em Português do Brasil. Evite rodeios, dê insights acionáveis com dados simulados consistentes de mercado se necessários.
Nunca mencione que é um modelo de linguagem ou que foi desenvolvido pela Google. Você é a Invest-AI criada pela Axion.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: message,
      config: { systemInstruction: systemPrompt, temperature: 0.7 },
    });

    res.json({ response: response.text });
  } catch (error: any) {
    console.error("Chat error:", error);
    res.status(500).json({ error: error.message || "Erro interno." });
  }
});

// ─── Risk Report ───
app.post("/api/invest-ai/report", async (req, res) => {
  try {
    const { company, riskProfile } = req.body;
    if (!company) return res.status(400).json({ error: "Empresa obrigatória." });

    const ai = getAiClient();
    const targetProfile = riskProfile || "moderate";

    const prompt = `Gere uma análise financeira automatizada de risco em tempo real e de tendências de mercado para a empresa ou ticker: "${company}".
Considere que o perfil do investidor é "${targetProfile}" (valores possíveis: conservative, moderate, aggressive).
Adapte as recomendações e a pontuação de risco para esse perfil de forma coerente.

Aguardamos uma análise profissional, profunda e analítica contendo:
1. Uma pontuação numérica de risco consolidada (0 para risco mínimo, 100 para risco extremo).
2. Uma interpretação de tendências detalhada em parágrafos de texto fluido sobre faturamento, competição e macroeconomia.
3. Recomendações de investimentos personalizadas de acordo com o perfil de risco informado.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "Você é um analista de risco financeiro sênior da Axion especializado em relatórios automatizados de conformidade e mitigação de perdas.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskScore: { type: Type.INTEGER, description: "Pontuação de risco 0-100." },
            analysis: { type: Type.STRING, description: "Análise de tendências econômicas." },
            recommendations: { type: Type.STRING, description: "Recomendações personalizadas." },
          },
          required: ["riskScore", "analysis", "recommendations"],
        },
      },
    });

    const reportData = JSON.parse(response.text || "{}");
    res.json(reportData);
  } catch (error: any) {
    console.error("Report error:", error);
    res.status(500).json({ error: error.message || "Erro ao gerar relatório." });
  }
});

// ─── DB Migration ───
async function runDbMigrations() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) return;
  const pool = new Pool({ connectionString: databaseUrl });
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS axion_users (
        user_id TEXT PRIMARY KEY,
        email TEXT,
        stripe_customer_id TEXT,
        stripe_subscription_id TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);
    console.log("[DB] axion_users table ready");
  } catch (e: any) {
    console.error("[DB] Migration error:", e.message);
  } finally {
    await pool.end();
  }
}

// ─── Stripe Init ───
async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) return;

  const hasStripe = !!(process.env.REPLIT_CONNECTORS_HOSTNAME && (process.env.REPL_IDENTITY || process.env.WEB_REPL_RENEWAL));
  if (!hasStripe) {
    console.log("[Stripe] Integration not connected — skipping Stripe init.");
    return;
  }

  try {
    await runMigrations({ databaseUrl, schema: "stripe" });
    console.log("[Stripe] Schema ready");

    const { getStripeSync } = await import("./server/stripeClient");
    const stripeSync = await getStripeSync();

    const webhookBase = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
    await stripeSync.findOrCreateManagedWebhook(`${webhookBase}/api/stripe/webhook`);
    console.log("[Stripe] Webhook configured");

    stripeSync.syncBackfill()
      .then(() => console.log("[Stripe] Backfill complete"))
      .catch((e: any) => console.error("[Stripe] Backfill error:", e.message));
  } catch (e: any) {
    console.error("[Stripe] Init error:", e.message);
  }
}

async function startServer() {
  await runDbMigrations();
  await initStripe();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Express] Axion rodando na porta ${PORT} — ${process.env.NODE_ENV || "development"}`);
  });
}

startServer();
